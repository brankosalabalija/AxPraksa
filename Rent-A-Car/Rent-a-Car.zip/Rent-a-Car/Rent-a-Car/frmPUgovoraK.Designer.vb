﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPUgovoraK
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmPUgovoraK))
        Me.RentaCarDataSet = New Rent_a_Car.RentaCarDataSet()
        Me.Ugovor_o_IZBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Ugovor_o_IZTableAdapter = New Rent_a_Car.RentaCarDataSetTableAdapters.Ugovor_o_IZTableAdapter()
        Me.TableAdapterManager = New Rent_a_Car.RentaCarDataSetTableAdapters.TableAdapterManager()
        Me.KlijentTableAdapter = New Rent_a_Car.RentaCarDataSetTableAdapters.KlijentTableAdapter()
        Me.SlužbenikTableAdapter = New Rent_a_Car.RentaCarDataSetTableAdapters.SlužbenikTableAdapter()
        Me.VoziloTableAdapter = New Rent_a_Car.RentaCarDataSetTableAdapters.VoziloTableAdapter()
        Me.Ugovor_o_IZBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.cmdNarad = New System.Windows.Forms.ToolStripButton()
        Me.Ugovor_o_IZDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.KlijentBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Column1 = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.SlužbenikBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Column2 = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.VoziloBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Column4 = New System.Windows.Forms.DataGridViewComboBoxColumn()
        CType(Me.RentaCarDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Ugovor_o_IZBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Ugovor_o_IZBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Ugovor_o_IZBindingNavigator.SuspendLayout()
        CType(Me.Ugovor_o_IZDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.KlijentBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SlužbenikBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VoziloBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'RentaCarDataSet
        '
        Me.RentaCarDataSet.DataSetName = "RentaCarDataSet"
        Me.RentaCarDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Ugovor_o_IZBindingSource
        '
        Me.Ugovor_o_IZBindingSource.DataMember = "Ugovor o IZ"
        Me.Ugovor_o_IZBindingSource.DataSource = Me.RentaCarDataSet
        '
        'Ugovor_o_IZTableAdapter
        '
        Me.Ugovor_o_IZTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.DobavljačTableAdapter = Nothing
        Me.TableAdapterManager.KlijentTableAdapter = Me.KlijentTableAdapter
        Me.TableAdapterManager.LoginTableAdapter = Nothing
        Me.TableAdapterManager.RačunTableAdapter = Nothing
        Me.TableAdapterManager.SlužbenikTableAdapter = Me.SlužbenikTableAdapter
        Me.TableAdapterManager.Stavka_računaTableAdapter = Nothing
        Me.TableAdapterManager.Ugovor_o_IZTableAdapter = Me.Ugovor_o_IZTableAdapter
        Me.TableAdapterManager.Ugovor_o_NVTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = Rent_a_Car.RentaCarDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.VoziloTableAdapter = Me.VoziloTableAdapter
        '
        'KlijentTableAdapter
        '
        Me.KlijentTableAdapter.ClearBeforeFill = True
        '
        'SlužbenikTableAdapter
        '
        Me.SlužbenikTableAdapter.ClearBeforeFill = True
        '
        'VoziloTableAdapter
        '
        Me.VoziloTableAdapter.ClearBeforeFill = True
        '
        'Ugovor_o_IZBindingNavigator
        '
        Me.Ugovor_o_IZBindingNavigator.AddNewItem = Nothing
        Me.Ugovor_o_IZBindingNavigator.BindingSource = Me.Ugovor_o_IZBindingSource
        Me.Ugovor_o_IZBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.Ugovor_o_IZBindingNavigator.DeleteItem = Nothing
        Me.Ugovor_o_IZBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.cmdNarad})
        Me.Ugovor_o_IZBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.Ugovor_o_IZBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.Ugovor_o_IZBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.Ugovor_o_IZBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.Ugovor_o_IZBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.Ugovor_o_IZBindingNavigator.Name = "Ugovor_o_IZBindingNavigator"
        Me.Ugovor_o_IZBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.Ugovor_o_IZBindingNavigator.Size = New System.Drawing.Size(965, 25)
        Me.Ugovor_o_IZBindingNavigator.TabIndex = 0
        Me.Ugovor_o_IZBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'cmdNarad
        '
        Me.cmdNarad.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.cmdNarad.Image = CType(resources.GetObject("cmdNarad.Image"), System.Drawing.Image)
        Me.cmdNarad.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmdNarad.Name = "cmdNarad"
        Me.cmdNarad.Size = New System.Drawing.Size(44, 22)
        Me.cmdNarad.Text = "Nazad"
        '
        'Ugovor_o_IZDataGridView
        '
        Me.Ugovor_o_IZDataGridView.AllowUserToAddRows = False
        Me.Ugovor_o_IZDataGridView.AllowUserToDeleteRows = False
        Me.Ugovor_o_IZDataGridView.AutoGenerateColumns = False
        Me.Ugovor_o_IZDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Ugovor_o_IZDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.Column1, Me.DataGridViewTextBoxColumn4, Me.Column2, Me.DataGridViewTextBoxColumn5, Me.Column3, Me.Column4})
        Me.Ugovor_o_IZDataGridView.DataSource = Me.Ugovor_o_IZBindingSource
        Me.Ugovor_o_IZDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Ugovor_o_IZDataGridView.Location = New System.Drawing.Point(0, 25)
        Me.Ugovor_o_IZDataGridView.Name = "Ugovor_o_IZDataGridView"
        Me.Ugovor_o_IZDataGridView.ReadOnly = True
        Me.Ugovor_o_IZDataGridView.Size = New System.Drawing.Size(965, 332)
        Me.Ugovor_o_IZDataGridView.TabIndex = 1
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "Šifra ugovora"
        Me.DataGridViewTextBoxColumn1.HeaderText = "Šifra ugovora"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "Datum"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Datum"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "JMBG Klijenta"
        Me.DataGridViewTextBoxColumn3.DataSource = Me.KlijentBindingSource
        Me.DataGridViewTextBoxColumn3.DisplayMember = "Prezime"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Prezime Klijenta"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.ReadOnly = True
        Me.DataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewTextBoxColumn3.ValueMember = "JMBG"
        '
        'KlijentBindingSource
        '
        Me.KlijentBindingSource.DataMember = "Klijent"
        Me.KlijentBindingSource.DataSource = Me.RentaCarDataSet
        '
        'Column1
        '
        Me.Column1.DataPropertyName = "JMBG Klijenta"
        Me.Column1.DataSource = Me.KlijentBindingSource
        Me.Column1.DisplayMember = "Ime"
        Me.Column1.HeaderText = "Ime Klijenta"
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        Me.Column1.ValueMember = "JMBG"
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "JMBG Službenika"
        Me.DataGridViewTextBoxColumn4.DataSource = Me.SlužbenikBindingSource
        Me.DataGridViewTextBoxColumn4.DisplayMember = "Prezime"
        Me.DataGridViewTextBoxColumn4.HeaderText = "Prezime Službenika"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.ReadOnly = True
        Me.DataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewTextBoxColumn4.ValueMember = "JMBG"
        '
        'SlužbenikBindingSource
        '
        Me.SlužbenikBindingSource.DataMember = "Službenik"
        Me.SlužbenikBindingSource.DataSource = Me.RentaCarDataSet
        '
        'Column2
        '
        Me.Column2.DataPropertyName = "JMBG Službenika"
        Me.Column2.DataSource = Me.SlužbenikBindingSource
        Me.Column2.DisplayMember = "Ime"
        Me.Column2.HeaderText = "Ime Službenika"
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        Me.Column2.ValueMember = "JMBG"
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "Br Šasije"
        Me.DataGridViewTextBoxColumn5.HeaderText = "Br Šasije"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.ReadOnly = True
        '
        'Column3
        '
        Me.Column3.DataPropertyName = "Br Šasije"
        Me.Column3.DataSource = Me.VoziloBindingSource
        Me.Column3.DisplayMember = "Marka vozila"
        Me.Column3.HeaderText = "Marka Vozila"
        Me.Column3.Name = "Column3"
        Me.Column3.ReadOnly = True
        Me.Column3.ValueMember = "Br šasije"
        '
        'VoziloBindingSource
        '
        Me.VoziloBindingSource.DataMember = "Vozilo"
        Me.VoziloBindingSource.DataSource = Me.RentaCarDataSet
        '
        'Column4
        '
        Me.Column4.DataPropertyName = "Br Šasije"
        Me.Column4.DataSource = Me.VoziloBindingSource
        Me.Column4.DisplayMember = "Model"
        Me.Column4.HeaderText = "Model"
        Me.Column4.Name = "Column4"
        Me.Column4.ReadOnly = True
        Me.Column4.ValueMember = "Br šasije"
        '
        'frmPUgovoraK
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(965, 357)
        Me.Controls.Add(Me.Ugovor_o_IZDataGridView)
        Me.Controls.Add(Me.Ugovor_o_IZBindingNavigator)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmPUgovoraK"
        Me.Text = "Ugovor o Izdavanju"
        CType(Me.RentaCarDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Ugovor_o_IZBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Ugovor_o_IZBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Ugovor_o_IZBindingNavigator.ResumeLayout(False)
        Me.Ugovor_o_IZBindingNavigator.PerformLayout()
        CType(Me.Ugovor_o_IZDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.KlijentBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SlužbenikBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VoziloBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents RentaCarDataSet As Rent_a_Car.RentaCarDataSet
    Friend WithEvents Ugovor_o_IZBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents Ugovor_o_IZTableAdapter As Rent_a_Car.RentaCarDataSetTableAdapters.Ugovor_o_IZTableAdapter
    Friend WithEvents TableAdapterManager As Rent_a_Car.RentaCarDataSetTableAdapters.TableAdapterManager
    Friend WithEvents Ugovor_o_IZBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Ugovor_o_IZDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents KlijentTableAdapter As Rent_a_Car.RentaCarDataSetTableAdapters.KlijentTableAdapter
    Friend WithEvents KlijentBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents SlužbenikTableAdapter As Rent_a_Car.RentaCarDataSetTableAdapters.SlužbenikTableAdapter
    Friend WithEvents SlužbenikBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents VoziloTableAdapter As Rent_a_Car.RentaCarDataSetTableAdapters.VoziloTableAdapter
    Friend WithEvents VoziloBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents cmdNarad As System.Windows.Forms.ToolStripButton
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents Column2 As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column3 As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents Column4 As System.Windows.Forms.DataGridViewComboBoxColumn
End Class
