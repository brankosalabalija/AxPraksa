﻿Partial Class dsqueryIzvjestajUI
End Class
