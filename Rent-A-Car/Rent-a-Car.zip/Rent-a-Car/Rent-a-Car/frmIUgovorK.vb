﻿Public Class frmIUgovorK

    Private Sub Ugovor_o_IZBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles Ugovor_o_IZBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.Ugovor_o_IZBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.RentaCarDataSet)

    End Sub

    Private Sub frmIUgovorK_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'RentaCarDataSet.Vozilo' table. You can move, or remove it, as needed.
        Me.VoziloTableAdapter.Fill(Me.RentaCarDataSet.Vozilo)
        'TODO: This line of code loads data into the 'RentaCarDataSet.Službenik' table. You can move, or remove it, as needed.
        Me.SlužbenikTableAdapter.Fill(Me.RentaCarDataSet.Službenik)
        'TODO: This line of code loads data into the 'RentaCarDataSet.Klijent' table. You can move, or remove it, as needed.
        Me.KlijentTableAdapter.Fill(Me.RentaCarDataSet.Klijent)
        'TODO: This line of code loads data into the 'RentaCarDataSet.Dobavljač' table. You can move, or remove it, as needed.
        Me.DobavljačTableAdapter.Fill(Me.RentaCarDataSet.Dobavljač)
        'TODO: This line of code loads data into the 'RentaCarDataSet.Ugovor_o_IZ' table. You can move, or remove it, as needed.
        Me.Ugovor_o_IZTableAdapter.Fill(Me.RentaCarDataSet.Ugovor_o_IZ)

    End Sub

    Private Sub ToolStripButton1_Click(sender As Object, e As EventArgs) Handles ToolStripButton1.Click
        Me.Close()

    End Sub
End Class