﻿Public Class frmMain

    Private Sub cmdExit_Click(sender As Object, e As EventArgs) Handles cmdExit.Click
        Application.Exit()
    End Sub

    Private Sub cmdKlijenti_Click(sender As Object, e As EventArgs) Handles cmdKlijenti.Click
        frmKlijenti.ShowDialog()
    End Sub

    Private Sub cmdVozila_Click(sender As Object, e As EventArgs) Handles cmdVozila.Click
        frmVozila.ShowDialog()
    End Sub

    Private Sub cmdIzdavanje_Click(sender As Object, e As EventArgs) Handles cmdUgovori.Click
        frmUgovori.ShowDialog()
    End Sub

    Private Sub cmdIzvjestaji_Click(sender As Object, e As EventArgs) Handles cmdIzvjestaji.Click
        frmIzvještaji.ShowDialog()
    End Sub

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub cmdDobavljaci_Click(sender As Object, e As EventArgs) Handles cmdDobavljaci.Click
        frmDobavljači.ShowDialog()
    End Sub
End Class