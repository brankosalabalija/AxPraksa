﻿Public Class frmPUgovoraV

    Private Sub Ugovor_o_NVBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)
        Me.Validate()
        Me.Ugovor_o_NVBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.RentaCarDataSet)

    End Sub

    Private Sub frmPUgovoraV_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'RentaCarDataSet.Vozilo' table. You can move, or remove it, as needed.
        Me.VoziloTableAdapter.Fill(Me.RentaCarDataSet.Vozilo)
        'TODO: This line of code loads data into the 'RentaCarDataSet.Službenik' table. You can move, or remove it, as needed.
        Me.SlužbenikTableAdapter.Fill(Me.RentaCarDataSet.Službenik)
        'TODO: This line of code loads data into the 'RentaCarDataSet.Dobavljač' table. You can move, or remove it, as needed.
        Me.DobavljačTableAdapter.Fill(Me.RentaCarDataSet.Dobavljač)
        'TODO: This line of code loads data into the 'RentaCarDataSet.Ugovor_o_NV' table. You can move, or remove it, as needed.
        Me.Ugovor_o_NVTableAdapter.Fill(Me.RentaCarDataSet.Ugovor_o_NV)

    End Sub

    Private Sub cmdNazad_Click(sender As Object, e As EventArgs) Handles cmdNazad.Click
        Me.Close()

    End Sub
End Class