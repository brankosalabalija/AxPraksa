﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDobavljači
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmDobavljači))
        Me.RentaCarDataSet = New Rent_a_Car.RentaCarDataSet()
        Me.DobavljačBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DobavljačTableAdapter = New Rent_a_Car.RentaCarDataSetTableAdapters.DobavljačTableAdapter()
        Me.TableAdapterManager = New Rent_a_Car.RentaCarDataSetTableAdapters.TableAdapterManager()
        Me.DobavljačBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.DobavljačBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.cmdNazad = New System.Windows.Forms.ToolStripButton()
        Me.DobavljačDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.RentaCarDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DobavljačBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DobavljačBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.DobavljačBindingNavigator.SuspendLayout()
        CType(Me.DobavljačDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'RentaCarDataSet
        '
        Me.RentaCarDataSet.DataSetName = "RentaCarDataSet"
        Me.RentaCarDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'DobavljačBindingSource
        '
        Me.DobavljačBindingSource.DataMember = "Dobavljač"
        Me.DobavljačBindingSource.DataSource = Me.RentaCarDataSet
        '
        'DobavljačTableAdapter
        '
        Me.DobavljačTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.DobavljačTableAdapter = Me.DobavljačTableAdapter
        Me.TableAdapterManager.KlijentTableAdapter = Nothing
        Me.TableAdapterManager.LoginTableAdapter = Nothing
        Me.TableAdapterManager.RačunTableAdapter = Nothing
        Me.TableAdapterManager.SlužbenikTableAdapter = Nothing
        Me.TableAdapterManager.Stavka_računaTableAdapter = Nothing
        Me.TableAdapterManager.Ugovor_o_IZTableAdapter = Nothing
        Me.TableAdapterManager.Ugovor_o_NVTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = Rent_a_Car.RentaCarDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.VoziloTableAdapter = Nothing
        '
        'DobavljačBindingNavigator
        '
        Me.DobavljačBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.DobavljačBindingNavigator.BindingSource = Me.DobavljačBindingSource
        Me.DobavljačBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.DobavljačBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.DobavljačBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.DobavljačBindingNavigatorSaveItem, Me.ToolStripSeparator1, Me.cmdNazad})
        Me.DobavljačBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.DobavljačBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.DobavljačBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.DobavljačBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.DobavljačBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.DobavljačBindingNavigator.Name = "DobavljačBindingNavigator"
        Me.DobavljačBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.DobavljačBindingNavigator.Size = New System.Drawing.Size(608, 25)
        Me.DobavljačBindingNavigator.TabIndex = 0
        Me.DobavljačBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'DobavljačBindingNavigatorSaveItem
        '
        Me.DobavljačBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.DobavljačBindingNavigatorSaveItem.Image = CType(resources.GetObject("DobavljačBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.DobavljačBindingNavigatorSaveItem.Name = "DobavljačBindingNavigatorSaveItem"
        Me.DobavljačBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.DobavljačBindingNavigatorSaveItem.Text = "Save Data"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'cmdNazad
        '
        Me.cmdNazad.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.cmdNazad.Image = CType(resources.GetObject("cmdNazad.Image"), System.Drawing.Image)
        Me.cmdNazad.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmdNazad.Name = "cmdNazad"
        Me.cmdNazad.Size = New System.Drawing.Size(44, 22)
        Me.cmdNazad.Text = "Nazad"
        '
        'DobavljačDataGridView
        '
        Me.DobavljačDataGridView.AutoGenerateColumns = False
        Me.DobavljačDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DobavljačDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3})
        Me.DobavljačDataGridView.DataSource = Me.DobavljačBindingSource
        Me.DobavljačDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DobavljačDataGridView.Location = New System.Drawing.Point(0, 25)
        Me.DobavljačDataGridView.Name = "DobavljačDataGridView"
        Me.DobavljačDataGridView.Size = New System.Drawing.Size(608, 403)
        Me.DobavljačDataGridView.TabIndex = 1
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "Šifra dobavljača"
        Me.DataGridViewTextBoxColumn1.HeaderText = "Šifra dobavljača"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "Ime dobavljača"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Ime dobavljača"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "Adresa"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Adresa"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        '
        'frmDobavljači
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(608, 428)
        Me.Controls.Add(Me.DobavljačDataGridView)
        Me.Controls.Add(Me.DobavljačBindingNavigator)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmDobavljači"
        Me.Text = "Dobavljači"
        CType(Me.RentaCarDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DobavljačBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DobavljačBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.DobavljačBindingNavigator.ResumeLayout(False)
        Me.DobavljačBindingNavigator.PerformLayout()
        CType(Me.DobavljačDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents RentaCarDataSet As Rent_a_Car.RentaCarDataSet
    Friend WithEvents DobavljačBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents DobavljačTableAdapter As Rent_a_Car.RentaCarDataSetTableAdapters.DobavljačTableAdapter
    Friend WithEvents TableAdapterManager As Rent_a_Car.RentaCarDataSetTableAdapters.TableAdapterManager
    Friend WithEvents DobavljačBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents DobavljačBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents cmdNazad As System.Windows.Forms.ToolStripButton
    Friend WithEvents DobavljačDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
