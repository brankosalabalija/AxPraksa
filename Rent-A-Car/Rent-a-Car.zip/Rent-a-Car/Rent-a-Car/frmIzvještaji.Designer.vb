﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmIzvještaji
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmIzvještaji))
        Me.cmdIzvještajUI = New System.Windows.Forms.Button()
        Me.cmdIzvještajUV = New System.Windows.Forms.Button()
        Me.cmdNazad = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'cmdIzvještajUI
        '
        Me.cmdIzvještajUI.Location = New System.Drawing.Point(40, 55)
        Me.cmdIzvještajUI.Name = "cmdIzvještajUI"
        Me.cmdIzvještajUI.Size = New System.Drawing.Size(118, 63)
        Me.cmdIzvještajUI.TabIndex = 0
        Me.cmdIzvještajUI.Text = "Ugovor o Izdavanju"
        Me.cmdIzvještajUI.UseVisualStyleBackColor = True
        '
        'cmdIzvještajUV
        '
        Me.cmdIzvještajUV.Location = New System.Drawing.Point(200, 55)
        Me.cmdIzvještajUV.Name = "cmdIzvještajUV"
        Me.cmdIzvještajUV.Size = New System.Drawing.Size(118, 63)
        Me.cmdIzvještajUV.TabIndex = 1
        Me.cmdIzvještajUV.Text = "Ugovor o Vozilima"
        Me.cmdIzvještajUV.UseVisualStyleBackColor = True
        '
        'cmdNazad
        '
        Me.cmdNazad.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdNazad.Location = New System.Drawing.Point(277, 154)
        Me.cmdNazad.Name = "cmdNazad"
        Me.cmdNazad.Size = New System.Drawing.Size(74, 32)
        Me.cmdNazad.TabIndex = 2
        Me.cmdNazad.Text = "Nazad"
        Me.cmdNazad.UseVisualStyleBackColor = True
        '
        'frmIzvještaji
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(363, 198)
        Me.Controls.Add(Me.cmdNazad)
        Me.Controls.Add(Me.cmdIzvještajUV)
        Me.Controls.Add(Me.cmdIzvještajUI)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmIzvještaji"
        Me.Text = "Izvještaji"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents cmdIzvještajUI As System.Windows.Forms.Button
    Friend WithEvents cmdIzvještajUV As System.Windows.Forms.Button
    Friend WithEvents cmdNazad As System.Windows.Forms.Button
End Class
