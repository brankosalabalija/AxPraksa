﻿Public Class frmUgovori

    Private Sub cmdNUgovor_Click(sender As Object, e As EventArgs) Handles cmdNUgovor.Click
        frmNUgovorV.ShowDialog()

    End Sub

    Private Sub cmdIugovor_Click(sender As Object, e As EventArgs) Handles cmdIugovor.Click
        frmIUgovorV.ShowDialog()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        frmNUgovorK.ShowDialog()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        frmIUgovorK.ShowDialog()
    End Sub

    Private Sub cmdNazad_Click(sender As Object, e As EventArgs) Handles cmdNazad.Click
        Me.Close()
    End Sub

    Private Sub cmdPUgovoreV_Click(sender As Object, e As EventArgs)
        frmPUgovoraV.ShowDialog()

    End Sub

    Private Sub cmdPUgovoreK_Click(sender As Object, e As EventArgs)
        frmPUgovoraK.ShowDialog()
    End Sub
End Class