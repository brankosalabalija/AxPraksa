﻿Public Class frmDobavljači

    Private Sub DobavljačBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles DobavljačBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.DobavljačBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.RentaCarDataSet)

    End Sub

    Private Sub Dobavljači_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'RentaCarDataSet.Dobavljač' table. You can move, or remove it, as needed.
        Me.DobavljačTableAdapter.Fill(Me.RentaCarDataSet.Dobavljač)

    End Sub

    Private Sub cmdNazad_Click(sender As Object, e As EventArgs) Handles cmdNazad.Click
        Me.Close()
    End Sub
End Class