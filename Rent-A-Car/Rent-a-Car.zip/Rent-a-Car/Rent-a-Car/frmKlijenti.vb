﻿Public Class frmKlijenti


    Private Sub KlijentBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles KlijentBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.KlijentBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.RentaCarDataSet)

    End Sub

    Private Sub frmKlijenti_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'RentaCarDataSet.Klijent' table. You can move, or remove it, as needed.
        Me.KlijentTableAdapter.Fill(Me.RentaCarDataSet.Klijent)

    End Sub

    Private Sub cmdNazad_Click(sender As Object, e As EventArgs) Handles cmdNazad.Click
        Me.Close()

    End Sub
End Class
