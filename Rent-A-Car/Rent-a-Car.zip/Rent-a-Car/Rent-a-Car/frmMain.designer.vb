﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.cmdExit = New System.Windows.Forms.Button()
        Me.cmdDobavljaci = New System.Windows.Forms.Button()
        Me.cmdUgovori = New System.Windows.Forms.Button()
        Me.cmdVozila = New System.Windows.Forms.Button()
        Me.cmdKlijenti = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.cmdIzvjestaji = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmdExit
        '
        Me.cmdExit.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdExit.Location = New System.Drawing.Point(473, 276)
        Me.cmdExit.Name = "cmdExit"
        Me.cmdExit.Size = New System.Drawing.Size(103, 36)
        Me.cmdExit.TabIndex = 5
        Me.cmdExit.Text = "Izlaz"
        Me.cmdExit.UseVisualStyleBackColor = True
        '
        'cmdDobavljaci
        '
        Me.cmdDobavljaci.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDobavljaci.Location = New System.Drawing.Point(290, 155)
        Me.cmdDobavljaci.Name = "cmdDobavljaci"
        Me.cmdDobavljaci.Size = New System.Drawing.Size(117, 47)
        Me.cmdDobavljaci.TabIndex = 8
        Me.cmdDobavljaci.Text = "Dobavljači"
        Me.cmdDobavljaci.UseVisualStyleBackColor = True
        '
        'cmdUgovori
        '
        Me.cmdUgovori.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdUgovori.Location = New System.Drawing.Point(413, 155)
        Me.cmdUgovori.Name = "cmdUgovori"
        Me.cmdUgovori.Size = New System.Drawing.Size(117, 47)
        Me.cmdUgovori.TabIndex = 1
        Me.cmdUgovori.Text = "Ugovori"
        Me.cmdUgovori.UseVisualStyleBackColor = True
        '
        'cmdVozila
        '
        Me.cmdVozila.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdVozila.Location = New System.Drawing.Point(167, 155)
        Me.cmdVozila.Name = "cmdVozila"
        Me.cmdVozila.Size = New System.Drawing.Size(117, 47)
        Me.cmdVozila.TabIndex = 9
        Me.cmdVozila.Text = "Vozila"
        Me.cmdVozila.UseVisualStyleBackColor = True
        '
        'cmdKlijenti
        '
        Me.cmdKlijenti.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdKlijenti.Location = New System.Drawing.Point(44, 155)
        Me.cmdKlijenti.Name = "cmdKlijenti"
        Me.cmdKlijenti.Size = New System.Drawing.Size(117, 47)
        Me.cmdKlijenti.TabIndex = 10
        Me.cmdKlijenti.Text = "Klijenti"
        Me.cmdKlijenti.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(44, 22)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(486, 127)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 11
        Me.PictureBox1.TabStop = False
        '
        'cmdIzvjestaji
        '
        Me.cmdIzvjestaji.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdIzvjestaji.Location = New System.Drawing.Point(228, 208)
        Me.cmdIzvjestaji.Name = "cmdIzvjestaji"
        Me.cmdIzvjestaji.Size = New System.Drawing.Size(117, 47)
        Me.cmdIzvjestaji.TabIndex = 12
        Me.cmdIzvjestaji.Text = "Izvještaji"
        Me.cmdIzvjestaji.UseVisualStyleBackColor = True
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(588, 324)
        Me.Controls.Add(Me.cmdIzvjestaji)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.cmdKlijenti)
        Me.Controls.Add(Me.cmdVozila)
        Me.Controls.Add(Me.cmdDobavljaci)
        Me.Controls.Add(Me.cmdUgovori)
        Me.Controls.Add(Me.cmdExit)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Rent-a-Car"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents cmdExit As System.Windows.Forms.Button
    Friend WithEvents cmdDobavljaci As System.Windows.Forms.Button
    Friend WithEvents cmdUgovori As System.Windows.Forms.Button
    Friend WithEvents cmdVozila As System.Windows.Forms.Button
    Friend WithEvents cmdKlijenti As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents cmdIzvjestaji As System.Windows.Forms.Button
End Class
