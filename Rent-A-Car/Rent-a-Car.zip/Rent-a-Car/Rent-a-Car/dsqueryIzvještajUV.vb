﻿

Partial Public Class dsqueryIzvještajUV
    Partial Class qryIzvjestajUVDataTable

        Private Sub qryIzvjestajUVDataTable_qryIzvjestajUVRowChanging(sender As Object, e As qryIzvjestajUVRowChangeEvent) Handles Me.qryIzvjestajUVRowChanging

        End Sub

    End Class

End Class
