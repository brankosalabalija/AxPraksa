﻿Imports System.Data.OleDb

Public Class frmLogin

    Private konekcija As New OleDbConnection
    Private objComm As OleDbCommand
    Private pokusaji As Integer


    Private Sub frmLogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        konekcija.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source='D:\BLC\Osnove Programiranja\Rent-a-Car\Rent-a-Car\RentaCar.mdb'"
        konekcija.Open()
        pokusaji = 0
    End Sub

    Private Sub frmLogin_Closed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        konekcija.Close()
        konekcija.Dispose()
    End Sub



    Private Sub cmdExit_Click(sender As Object, e As EventArgs) Handles cmdExit.Click
        Application.Exit()
    End Sub

    Private Sub cmdLogin_Click(sender As Object, e As EventArgs) Handles cmdLogin.Click
        pokusaji += 1

        Dim sqlQuery As String
        sqlQuery = "SELECT COUNT(*) FROM Login " & "WHERE username='" & Trim(Me.txtUsername.Text) & "' AND password='" & Trim(Me.txtPassword.Text) & "'"
        objComm = New OleDbCommand(sqlQuery, konekcija)
        objComm.CommandType = CommandType.Text

        If objComm.ExecuteScalar() = 1 Then
            frmMain.Show()
            Me.Close()
        ElseIf pokusaji < 3 Then
            MsgBox("Pogrešno korisničko ime i/ili lozinka" & vbNewLine & vbNewLine & "Molim pokušaj ponovo" & vbNewLine & "Preostalo pokušaja" & (3 - pokusaji), vbOK + vbCritical, "Prijavljivanje")
        ElseIf pokusaji = 3 Then
            MsgBox("3 neuspješna pokušaja!!!" & vbNewLine & vbNewLine & "Pokrenite program ponovo", vbOK + vbCritical, "Prijavljivanje")
            Me.Close()
        End If


    End Sub
End Class
