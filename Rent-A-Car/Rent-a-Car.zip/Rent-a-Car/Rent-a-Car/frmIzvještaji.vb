﻿Public Class frmIzvještaji

    Private Sub cmdIzvještajUI_Click(sender As Object, e As EventArgs) Handles cmdIzvještajUI.Click
        frmPUgovoraK.ShowDialog()



    End Sub

    Private Sub cmdIzvještajUV_Click(sender As Object, e As EventArgs) Handles cmdIzvještajUV.Click
        frmPUgovoraV.ShowDialog()


    End Sub

    Private Sub cmdNazad_Click(sender As Object, e As EventArgs) Handles cmdNazad.Click
        Me.Close()
    End Sub
End Class