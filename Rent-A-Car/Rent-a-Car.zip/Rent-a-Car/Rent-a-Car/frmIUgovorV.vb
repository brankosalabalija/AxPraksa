﻿Public Class frmIUgovorV


    
    Private Sub Ugovor_o_NVBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles Ugovor_o_NVBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.Ugovor_o_NVBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.RentaCarDataSet)

    End Sub

    Private Sub frmIUgovorV_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'RentaCarDataSet.Službenik' table. You can move, or remove it, as needed.
        Me.SlužbenikTableAdapter.Fill(Me.RentaCarDataSet.Službenik)
        'TODO: This line of code loads data into the 'RentaCarDataSet.Dobavljač' table. You can move, or remove it, as needed.
        Me.DobavljačTableAdapter.Fill(Me.RentaCarDataSet.Dobavljač)
        'TODO: This line of code loads data into the 'RentaCarDataSet.Ugovor_o_NV' table. You can move, or remove it, as needed.
        Me.Ugovor_o_NVTableAdapter.Fill(Me.RentaCarDataSet.Ugovor_o_NV)

    End Sub

    Private Sub ToolStripButton1_Click(sender As Object, e As EventArgs) Handles ToolStripButton1.Click
        Me.Close()

    End Sub
End Class