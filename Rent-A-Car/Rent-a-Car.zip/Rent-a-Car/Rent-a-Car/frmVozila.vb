﻿Public Class frmVozila

    Private Sub VoziloBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles VoziloBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.VoziloBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.RentaCarDataSet)

    End Sub

    Private Sub frmVozila_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'RentaCarDataSet.Vozilo' table. You can move, or remove it, as needed.
        Me.VoziloTableAdapter.Fill(Me.RentaCarDataSet.Vozilo)

    End Sub

    Private Sub ToolStripButton1_Click(sender As Object, e As EventArgs) Handles ToolStripButton1.Click
        Me.Close()

    End Sub
End Class