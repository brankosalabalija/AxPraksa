﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmNUgovorK
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Šifra_ugovoraLabel As System.Windows.Forms.Label
        Dim DatumLabel As System.Windows.Forms.Label
        Dim JMBG_KlijentaLabel As System.Windows.Forms.Label
        Dim JMBG_SlužbenikaLabel As System.Windows.Forms.Label
        Dim Br_ŠasijeLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmNUgovorK))
        Me.RentaCarDataSet = New Rent_a_Car.RentaCarDataSet()
        Me.Ugovor_o_IZBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Ugovor_o_IZTableAdapter = New Rent_a_Car.RentaCarDataSetTableAdapters.Ugovor_o_IZTableAdapter()
        Me.TableAdapterManager = New Rent_a_Car.RentaCarDataSetTableAdapters.TableAdapterManager()
        Me.KlijentTableAdapter = New Rent_a_Car.RentaCarDataSetTableAdapters.KlijentTableAdapter()
        Me.SlužbenikTableAdapter = New Rent_a_Car.RentaCarDataSetTableAdapters.SlužbenikTableAdapter()
        Me.VoziloTableAdapter = New Rent_a_Car.RentaCarDataSetTableAdapters.VoziloTableAdapter()
        Me.Ugovor_o_IZBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.Ugovor_o_IZBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.cmdNazad = New System.Windows.Forms.ToolStripButton()
        Me.Šifra_ugovoraTextBox = New System.Windows.Forms.TextBox()
        Me.DatumTextBox = New System.Windows.Forms.TextBox()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.KlijentBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.ComboBox3 = New System.Windows.Forms.ComboBox()
        Me.SlužbenikBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ComboBox4 = New System.Windows.Forms.ComboBox()
        Me.ComboBox5 = New System.Windows.Forms.ComboBox()
        Me.VoziloBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ComboBox6 = New System.Windows.Forms.ComboBox()
        Šifra_ugovoraLabel = New System.Windows.Forms.Label()
        DatumLabel = New System.Windows.Forms.Label()
        JMBG_KlijentaLabel = New System.Windows.Forms.Label()
        JMBG_SlužbenikaLabel = New System.Windows.Forms.Label()
        Br_ŠasijeLabel = New System.Windows.Forms.Label()
        CType(Me.RentaCarDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Ugovor_o_IZBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Ugovor_o_IZBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Ugovor_o_IZBindingNavigator.SuspendLayout()
        CType(Me.KlijentBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SlužbenikBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VoziloBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Šifra_ugovoraLabel
        '
        Šifra_ugovoraLabel.AutoSize = True
        Šifra_ugovoraLabel.Location = New System.Drawing.Point(140, 90)
        Šifra_ugovoraLabel.Name = "Šifra_ugovoraLabel"
        Šifra_ugovoraLabel.Size = New System.Drawing.Size(73, 13)
        Šifra_ugovoraLabel.TabIndex = 1
        Šifra_ugovoraLabel.Text = "Šifra ugovora:"
        '
        'DatumLabel
        '
        DatumLabel.AutoSize = True
        DatumLabel.Location = New System.Drawing.Point(172, 116)
        DatumLabel.Name = "DatumLabel"
        DatumLabel.Size = New System.Drawing.Size(41, 13)
        DatumLabel.TabIndex = 3
        DatumLabel.Text = "Datum:"
        '
        'JMBG_KlijentaLabel
        '
        JMBG_KlijentaLabel.AutoSize = True
        JMBG_KlijentaLabel.Location = New System.Drawing.Point(105, 142)
        JMBG_KlijentaLabel.Name = "JMBG_KlijentaLabel"
        JMBG_KlijentaLabel.Size = New System.Drawing.Size(108, 13)
        JMBG_KlijentaLabel.TabIndex = 5
        JMBG_KlijentaLabel.Text = "Prezime i ime Klijenta:"
        '
        'JMBG_SlužbenikaLabel
        '
        JMBG_SlužbenikaLabel.AutoSize = True
        JMBG_SlužbenikaLabel.Location = New System.Drawing.Point(87, 168)
        JMBG_SlužbenikaLabel.Name = "JMBG_SlužbenikaLabel"
        JMBG_SlužbenikaLabel.Size = New System.Drawing.Size(126, 13)
        JMBG_SlužbenikaLabel.TabIndex = 7
        JMBG_SlužbenikaLabel.Text = "Prezime i ime Službenika:"
        '
        'Br_ŠasijeLabel
        '
        Br_ŠasijeLabel.AutoSize = True
        Br_ŠasijeLabel.Location = New System.Drawing.Point(172, 194)
        Br_ŠasijeLabel.Name = "Br_ŠasijeLabel"
        Br_ŠasijeLabel.Size = New System.Drawing.Size(38, 13)
        Br_ŠasijeLabel.TabIndex = 9
        Br_ŠasijeLabel.Text = "Vozilo:"
        '
        'RentaCarDataSet
        '
        Me.RentaCarDataSet.DataSetName = "RentaCarDataSet"
        Me.RentaCarDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Ugovor_o_IZBindingSource
        '
        Me.Ugovor_o_IZBindingSource.DataMember = "Ugovor o IZ"
        Me.Ugovor_o_IZBindingSource.DataSource = Me.RentaCarDataSet
        '
        'Ugovor_o_IZTableAdapter
        '
        Me.Ugovor_o_IZTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.DobavljačTableAdapter = Nothing
        Me.TableAdapterManager.KlijentTableAdapter = Me.KlijentTableAdapter
        Me.TableAdapterManager.LoginTableAdapter = Nothing
        Me.TableAdapterManager.RačunTableAdapter = Nothing
        Me.TableAdapterManager.SlužbenikTableAdapter = Me.SlužbenikTableAdapter
        Me.TableAdapterManager.Stavka_računaTableAdapter = Nothing
        Me.TableAdapterManager.Ugovor_o_IZTableAdapter = Me.Ugovor_o_IZTableAdapter
        Me.TableAdapterManager.Ugovor_o_NVTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = Rent_a_Car.RentaCarDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.VoziloTableAdapter = Me.VoziloTableAdapter
        '
        'KlijentTableAdapter
        '
        Me.KlijentTableAdapter.ClearBeforeFill = True
        '
        'SlužbenikTableAdapter
        '
        Me.SlužbenikTableAdapter.ClearBeforeFill = True
        '
        'VoziloTableAdapter
        '
        Me.VoziloTableAdapter.ClearBeforeFill = True
        '
        'Ugovor_o_IZBindingNavigator
        '
        Me.Ugovor_o_IZBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.Ugovor_o_IZBindingNavigator.BindingSource = Me.Ugovor_o_IZBindingSource
        Me.Ugovor_o_IZBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.Ugovor_o_IZBindingNavigator.DeleteItem = Nothing
        Me.Ugovor_o_IZBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.Ugovor_o_IZBindingNavigatorSaveItem, Me.ToolStripSeparator1, Me.cmdNazad})
        Me.Ugovor_o_IZBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.Ugovor_o_IZBindingNavigator.MoveFirstItem = Nothing
        Me.Ugovor_o_IZBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.Ugovor_o_IZBindingNavigator.MoveNextItem = Nothing
        Me.Ugovor_o_IZBindingNavigator.MovePreviousItem = Nothing
        Me.Ugovor_o_IZBindingNavigator.Name = "Ugovor_o_IZBindingNavigator"
        Me.Ugovor_o_IZBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.Ugovor_o_IZBindingNavigator.Size = New System.Drawing.Size(632, 25)
        Me.Ugovor_o_IZBindingNavigator.TabIndex = 0
        Me.Ugovor_o_IZBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.ReadOnly = True
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'Ugovor_o_IZBindingNavigatorSaveItem
        '
        Me.Ugovor_o_IZBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.Ugovor_o_IZBindingNavigatorSaveItem.Image = CType(resources.GetObject("Ugovor_o_IZBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.Ugovor_o_IZBindingNavigatorSaveItem.Name = "Ugovor_o_IZBindingNavigatorSaveItem"
        Me.Ugovor_o_IZBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.Ugovor_o_IZBindingNavigatorSaveItem.Text = "Save Data"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'cmdNazad
        '
        Me.cmdNazad.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.cmdNazad.Image = CType(resources.GetObject("cmdNazad.Image"), System.Drawing.Image)
        Me.cmdNazad.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.cmdNazad.Name = "cmdNazad"
        Me.cmdNazad.Size = New System.Drawing.Size(44, 22)
        Me.cmdNazad.Text = "Nazad"
        '
        'Šifra_ugovoraTextBox
        '
        Me.Šifra_ugovoraTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Ugovor_o_IZBindingSource, "Šifra ugovora", True))
        Me.Šifra_ugovoraTextBox.Location = New System.Drawing.Point(219, 87)
        Me.Šifra_ugovoraTextBox.MaxLength = 9
        Me.Šifra_ugovoraTextBox.Name = "Šifra_ugovoraTextBox"
        Me.Šifra_ugovoraTextBox.Size = New System.Drawing.Size(131, 20)
        Me.Šifra_ugovoraTextBox.TabIndex = 2
        '
        'DatumTextBox
        '
        Me.DatumTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Ugovor_o_IZBindingSource, "Datum", True))
        Me.DatumTextBox.Location = New System.Drawing.Point(219, 113)
        Me.DatumTextBox.Name = "DatumTextBox"
        Me.DatumTextBox.Size = New System.Drawing.Size(131, 20)
        Me.DatumTextBox.TabIndex = 4
        '
        'ComboBox1
        '
        Me.ComboBox1.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.Ugovor_o_IZBindingSource, "JMBG Klijenta", True))
        Me.ComboBox1.DataSource = Me.KlijentBindingSource
        Me.ComboBox1.DisplayMember = "Prezime"
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(219, 138)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(131, 21)
        Me.ComboBox1.TabIndex = 11
        Me.ComboBox1.ValueMember = "JMBG"
        '
        'KlijentBindingSource
        '
        Me.KlijentBindingSource.DataMember = "Klijent"
        Me.KlijentBindingSource.DataSource = Me.RentaCarDataSet
        '
        'ComboBox2
        '
        Me.ComboBox2.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.Ugovor_o_IZBindingSource, "JMBG Klijenta", True))
        Me.ComboBox2.DataSource = Me.KlijentBindingSource
        Me.ComboBox2.DisplayMember = "Ime"
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Location = New System.Drawing.Point(356, 138)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(131, 21)
        Me.ComboBox2.TabIndex = 12
        Me.ComboBox2.ValueMember = "JMBG"
        '
        'ComboBox3
        '
        Me.ComboBox3.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.Ugovor_o_IZBindingSource, "JMBG Službenika", True))
        Me.ComboBox3.DataSource = Me.SlužbenikBindingSource
        Me.ComboBox3.DisplayMember = "Prezime"
        Me.ComboBox3.FormattingEnabled = True
        Me.ComboBox3.Location = New System.Drawing.Point(219, 165)
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(131, 21)
        Me.ComboBox3.TabIndex = 13
        Me.ComboBox3.ValueMember = "JMBG"
        '
        'SlužbenikBindingSource
        '
        Me.SlužbenikBindingSource.DataMember = "Službenik"
        Me.SlužbenikBindingSource.DataSource = Me.RentaCarDataSet
        '
        'ComboBox4
        '
        Me.ComboBox4.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.Ugovor_o_IZBindingSource, "JMBG Službenika", True))
        Me.ComboBox4.DataSource = Me.SlužbenikBindingSource
        Me.ComboBox4.DisplayMember = "Ime"
        Me.ComboBox4.FormattingEnabled = True
        Me.ComboBox4.Location = New System.Drawing.Point(356, 165)
        Me.ComboBox4.Name = "ComboBox4"
        Me.ComboBox4.Size = New System.Drawing.Size(131, 21)
        Me.ComboBox4.TabIndex = 14
        Me.ComboBox4.ValueMember = "JMBG"
        '
        'ComboBox5
        '
        Me.ComboBox5.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.Ugovor_o_IZBindingSource, "Br Šasije", True))
        Me.ComboBox5.DataSource = Me.VoziloBindingSource
        Me.ComboBox5.DisplayMember = "Marka vozila"
        Me.ComboBox5.FormattingEnabled = True
        Me.ComboBox5.Location = New System.Drawing.Point(219, 191)
        Me.ComboBox5.Name = "ComboBox5"
        Me.ComboBox5.Size = New System.Drawing.Size(131, 21)
        Me.ComboBox5.TabIndex = 15
        Me.ComboBox5.ValueMember = "Br šasije"
        '
        'VoziloBindingSource
        '
        Me.VoziloBindingSource.DataMember = "Vozilo"
        Me.VoziloBindingSource.DataSource = Me.RentaCarDataSet
        '
        'ComboBox6
        '
        Me.ComboBox6.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.Ugovor_o_IZBindingSource, "Br Šasije", True))
        Me.ComboBox6.DataSource = Me.VoziloBindingSource
        Me.ComboBox6.DisplayMember = "Model"
        Me.ComboBox6.FormattingEnabled = True
        Me.ComboBox6.Location = New System.Drawing.Point(356, 191)
        Me.ComboBox6.Name = "ComboBox6"
        Me.ComboBox6.Size = New System.Drawing.Size(131, 21)
        Me.ComboBox6.TabIndex = 16
        Me.ComboBox6.ValueMember = "Br šasije"
        '
        'frmNUgovorK
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(632, 248)
        Me.Controls.Add(Me.ComboBox6)
        Me.Controls.Add(Me.ComboBox5)
        Me.Controls.Add(Me.ComboBox4)
        Me.Controls.Add(Me.ComboBox3)
        Me.Controls.Add(Me.ComboBox2)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Šifra_ugovoraLabel)
        Me.Controls.Add(Me.Šifra_ugovoraTextBox)
        Me.Controls.Add(DatumLabel)
        Me.Controls.Add(Me.DatumTextBox)
        Me.Controls.Add(JMBG_KlijentaLabel)
        Me.Controls.Add(JMBG_SlužbenikaLabel)
        Me.Controls.Add(Br_ŠasijeLabel)
        Me.Controls.Add(Me.Ugovor_o_IZBindingNavigator)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmNUgovorK"
        Me.Text = "Novi Ugovor"
        CType(Me.RentaCarDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Ugovor_o_IZBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Ugovor_o_IZBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Ugovor_o_IZBindingNavigator.ResumeLayout(False)
        Me.Ugovor_o_IZBindingNavigator.PerformLayout()
        CType(Me.KlijentBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SlužbenikBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VoziloBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents RentaCarDataSet As Rent_a_Car.RentaCarDataSet
    Friend WithEvents Ugovor_o_IZBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents Ugovor_o_IZTableAdapter As Rent_a_Car.RentaCarDataSetTableAdapters.Ugovor_o_IZTableAdapter
    Friend WithEvents TableAdapterManager As Rent_a_Car.RentaCarDataSetTableAdapters.TableAdapterManager
    Friend WithEvents Ugovor_o_IZBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Ugovor_o_IZBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents Šifra_ugovoraTextBox As System.Windows.Forms.TextBox
    Friend WithEvents DatumTextBox As System.Windows.Forms.TextBox
    Friend WithEvents KlijentTableAdapter As Rent_a_Car.RentaCarDataSetTableAdapters.KlijentTableAdapter
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents KlijentBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents SlužbenikTableAdapter As Rent_a_Car.RentaCarDataSetTableAdapters.SlužbenikTableAdapter
    Friend WithEvents ComboBox2 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox3 As System.Windows.Forms.ComboBox
    Friend WithEvents SlužbenikBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents VoziloTableAdapter As Rent_a_Car.RentaCarDataSetTableAdapters.VoziloTableAdapter
    Friend WithEvents ComboBox4 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox5 As System.Windows.Forms.ComboBox
    Friend WithEvents VoziloBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents cmdNazad As System.Windows.Forms.ToolStripButton
    Friend WithEvents ComboBox6 As System.Windows.Forms.ComboBox
End Class
