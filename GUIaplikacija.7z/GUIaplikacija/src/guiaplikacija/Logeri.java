/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guiaplikacija;

/**
 *
 * @author branko.salabalija
 */
interface Logeri {
    
    void ispisGreska(String greska);
    void ispisPozicija(String pozicija);
    void ispisPoruka(String poruka);
    
    void logGreska(String greska);
    void logAVLPozicija(String avlPozicija);
    void logAVLPoruke(String avlPoruka);
}
