/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guiaplikacija;

import java.io.DataInputStream;
import java.io.DataOutputStream;

/**
 *
 * @author branko.salabalija
 */

public class Uredjaj{
    private String ip = null;
    private int port = -1;
    private int connectionNumber = -1;
    private int brojUredjaja = -1;
    private long IMEI_Uredjaj = -1;
    private String Gtime = null;
    private String GtimeTest = null;
    private String brojKartice = null;
    private String nazivGrupe = null;
    private short GCTip = -1;
    private String regBrVozila = null;
    private String datumUgradnje = null;
    private int IDVozila = -1;
    private int vrijemeSlanja = -1;
    private int vrijemeSlanjaEngineOff = -1;
    private String tipUredjaja = null;
    private String sifraUredjaja = null;
    private String Firmware = null;
    private short PDA = -1; 
    private short sleepMode = -1;
    private String identHex = null;
    private short IDVozaca = -1;
    private int ugaoSlanja = -1; //direction
    private int distancaSlanja = -1; //
    private String simKarticaProvider = null;
    private float X = -999;
    private float Y = -999;
    private short event = -1;
    private short runMode = -1;
    private short statusRuteX11 = 0;
    private float speed = -1;
    private int direction = -1;
    private int altitude = -1 ;
    private short satellites = -1;
    private short GsmSignalLevel = -1;
    private int accuracy = -1;
    private float batteryLevel = -1;
    private float analog1 = -1;
    private float analog2 = -1;
    private float gForceX = -1;
    private float gForceY = -1;
    private float gForceZ = -1;
    private int fls = -1; //-1 ili 1
    private float flsLevel1 = -1; 
    private float flsLevel2 = -1;
    private float flsDiff1 = -1;
    private float flsDiff2 = -1;
    private float fuelTemperature1 = -1;
    private float fuelTemperature2 = -1;
    private int speedMax = -1;
    private float tempSensor1 = -1;
    private float tempSensor2 = -1;
    private float tempSensor3 = -1;
    private float tempSensor4 = -1;
    private float powerSupply = -1;
    private double mileage = -1;
    private float odometer = -1;
    private String geocode = null;
    private int jammer = -1;
    private int fk_ID_vozac = -1;
    private short Ident = -1;
    private short tmp1 = -1;
    private short tmp2 = -1 ;
    private int tmp3 = -1;
    private float tmp4 = -1;
    private short redniBrojPozicije = -1;
    private int fk_ID_moje_lokacije = -1;
    
    private DataOutputStream udos = null;
    private DataInputStream udis = null;
    private Parametri par = null; 
    private Logeri loger = null;

    /**
     * Konstruktor Uredjaj za objekat sa pocetnim vrijednostima
     */
    public Uredjaj() {
    }
    
    /**
     * Konstruktor privremenog objekta Uredjaj koji predstavlja stvarni uredjaj
     * koji se prijavljuje na Javu
     * @param udis 
     * @param udos 
     * @param ip 
     * @param port 
     * @param lg 
     * @param par 
     */
    public Uredjaj(DataInputStream udis, DataOutputStream udos, String ip, int port, Logeri lg, Parametri par){
        this.udis = udis;
        this.udos = udos;
        this.ip = ip;
        this.port = port;
        this.loger = lg;
        this.par = par;
    }
    
    /**
     * Konstruktor za uredjaj iz gps_fresh tabele
     * 
     * @param brojUredjaja
     * @param fX
     * @param fY
     * @param Gtime
     * @param Event
     * @param RunMode
     * @param Speed
     * @param Direction
     * @param Altitude
     * @param Sattelites
     * @param GmsSignalLevel
     * @param Accuracy
     * @param BatteryLevel
     * @param Analog1
     * @param Analog2
     * @param FlsLevel1
     * @param FlsLevel2
     * @param FuelTemperature1
     * @param FuelTemperature2
     * @param PowerSupply
     * @param Mileage
     * @param Odometer
     * @param GeoCode
     * @param fkIdVozac 
     */
    public Uredjaj(int brojUredjaja, float fX, float fY, String Gtime, short Event, short RunMode, float Speed, int Direction, int Altitude, 
            short Sattelites, short GmsSignalLevel, int Accuracy, float BatteryLevel, float Analog1, float Analog2, float FlsLevel1,
            float FlsLevel2, float FuelTemperature1, float FuelTemperature2, float PowerSupply, double Mileage, float Odometer, String GeoCode,
            short fkIdVozac){
        this.brojUredjaja = brojUredjaja;
        this.X = fX;
        this.Y = fY;
        this.Gtime = Gtime;
        this.event = Event;
        this.runMode = RunMode;
        this.speed = Speed;
        this.direction = Direction;
        this.altitude = Altitude;
        this.satellites = Sattelites;
        this.GsmSignalLevel = GmsSignalLevel;
        this.accuracy = Accuracy;
        this.batteryLevel = BatteryLevel;
        this.analog1 = Analog1;
        this.analog2 = Analog2;
        this.flsLevel1 = FlsLevel1;
        this.flsLevel2 = FlsLevel2;
        this.fuelTemperature1 = FuelTemperature1;
        this.fuelTemperature2 = FuelTemperature2;
        this.powerSupply = PowerSupply;
        this.mileage = Mileage;
        this.odometer = Odometer;
        this.geocode = GeoCode;
        this.fk_ID_vozac = fkIdVozac;
    }

    /**
     * Konstruktor za uredjaj koji se dobije iz baze pri inicijalnom pokretanju jave
     * 
     * @param brojUredjaja
     * @param IMEI_Uredjaj
     * @param Gtime
     * @param brojKartice
     * @param nazivGrupe
     * @param GCTip
     * @param regBrVozila
     * @param datumUgradnje
     * @param IDVozila
     * @param vrijemeSlanja
     * @param vrijemeSlanjaEngineOff
     * @param tipUredjaja
     * @param sifraUredjaja
     * @param firmware
     * @param PDA
     * @param sleepMode
     * @param identHex
     * @param IDVozaca
     * @param ugaoSlanja
     * @param distancaSlanja
     * @param simKarticaProvider 
     * @param lg 
     * @param par 
     */
    public Uredjaj(int brojUredjaja, long IMEI_Uredjaj, String Gtime, String brojKartice, String nazivGrupe, short GCTip, String regBrVozila,
            String datumUgradnje, int IDVozila, int vrijemeSlanja, int vrijemeSlanjaEngineOff, String tipUredjaja, String sifraUredjaja,
            String firmware, short PDA, short sleepMode, String identHex, short IDVozaca, int ugaoSlanja, int distancaSlanja,
            String simKarticaProvider, Logeri lg, Parametri par) {
        this.brojUredjaja = brojUredjaja;
        this.IMEI_Uredjaj = IMEI_Uredjaj;
        this.Gtime = Gtime;
        this.brojKartice = brojKartice;
        this.nazivGrupe = nazivGrupe;
        this.GCTip = GCTip;
        this.regBrVozila = regBrVozila;
        this.datumUgradnje = datumUgradnje;
        this.IDVozila = IDVozila;
        this.vrijemeSlanja = vrijemeSlanja;
        this.vrijemeSlanjaEngineOff = vrijemeSlanjaEngineOff;
        this.tipUredjaja = tipUredjaja;
        this.sifraUredjaja = sifraUredjaja;
        this.Firmware = firmware;
        this.PDA = PDA;
        this.sleepMode = sleepMode;
        this.identHex = identHex;
        this.IDVozaca = IDVozaca;
        this.ugaoSlanja = ugaoSlanja;
        this.distancaSlanja = distancaSlanja;
        this.simKarticaProvider = simKarticaProvider;
        this.loger = lg;
        this.par = par;
    }
    
    public void dodajIpPortInfo(Uredjaj uredjaj){
        this.udos = uredjaj.udos;
        this.udis = uredjaj.udis;
        this.ip = uredjaj.ip;
        this.port = uredjaj.port;
    }
    
    /**
     * Funkcija koja pravi SQL naredbu za upis podataka u gps tabelu
     * @return {@code String} koji predstavlja SQL naredbu
     */
    public String upis_FM_Teltonika(){
        String upis = "{CALL `java2db_FM_Teltonika` (" + this.brojUredjaja + "," + this.X + "," + this.Y + ",'" + this.Gtime + 
                "'," + this.event + "," + this.runMode + "," + this.speed + "," + this.direction + "," + this.altitude + "," + this.satellites + "," +
                this.GsmSignalLevel + "," + this.accuracy + "," + this.batteryLevel + "," + this.analog1 + "," + this.analog2 + "," + this.gForceX + "," + 
                this.gForceY + "," + this.gForceZ + "," + this.flsLevel1 + "," + this.flsLevel2 + "," + this.mileage + "," + this.odometer + "," +
                "'BanjaLuka'" + "," + this.fk_ID_vozac + "," + this.tmp1 + "," + this.tmp2 + "," + this.tmp3 + "," + this.tmp4 + "," + this.fls + "," +
                this.flsDiff1 + "," + this.flsDiff2 + "," + this.speedMax + "," + this.fk_ID_moje_lokacije + "," + this.Ident + "," + this.tempSensor1 +
                "," + this.tempSensor2 + "," + this.tempSensor3 + "," + this.tempSensor4 + "," + this.fuelTemperature1 + "," + this.fuelTemperature2 +
                "," + this.powerSupply + "," + this.jammer + "," + this.redniBrojPozicije + ")}";
        
        return upis;
    }
    
    public String upis_GL300N(){
        String upis = "{CALL `java2db_GL`(" + this.brojUredjaja + "," + this.X +"," + this.Y + ",'" + this.Gtime + "'," + this.event + ","
                + this.runMode + "," + this.speed + "," + this.direction + "," + this.altitude + "," + this.satellites + ","
                + this.GsmSignalLevel + "," + this.accuracy + "," + this.batteryLevel + "," + this.analog1 + "," +this.analog2 + "," 
                + this.gForceX + "," + this.gForceY + "," + this.gForceZ + "," + this.flsLevel1 + "," + this.flsLevel2 + "," + this.mileage + ","
                + this.odometer + ",'" + this.geocode + "'," + this.IDVozaca + "," + this.tmp1 + "," + this.tmp2 + "," + this.tmp3 + ","
                + this.tmp4 + "," + this.speedMax + "," + this.fk_ID_moje_lokacije + ")}";
            
        return upis;
    }
    
    /**
     * Ispis informacija o uredjaju
     * @return {@code String}
     */
    public String ispisInformacija() {
        return "Uredjaj: " + brojUredjaja + "\tTipUredjaja: " + tipUredjaja + "\tVrijeme: " + Gtime +"\tIP: " + ip + ":" + port +
                "\tBrojKartice: " + brojKartice + "\tIMEI_Uredjaj: " + IMEI_Uredjaj +"\tGrupa: " + nazivGrupe + "\tPass: " + sifraUredjaja +
                "\tIMEI: " + IMEI_Uredjaj + "\tFW: " + Firmware  + "\tGCTip: " + GCTip + "\tPDA: " + PDA + "\tSleepMode: " + sleepMode +
                "\tRegBrVozila: " + regBrVozila + "\tDatumUgradnje: " + datumUgradnje + "\tIdent: " + identHex  + "\tIDVozila: " + IDVozila +
                "\tIDVozaca: " + IDVozaca + "\tVrijeme: " + vrijemeSlanja + " s ( " + vrijemeSlanjaEngineOff + " s )" +
                "\tUgao: " + ugaoSlanja + "  Distanca: " + distancaSlanja + "\tSimKarticaProvider: " + simKarticaProvider;
    }
    
    /**
     * Ispis podataka pozicije uredjaja
     * @param numIO ukupan broj IO elemenata koje je uredjaj poslao u jednoj poruci
     * @param numAVL redni broj AVL poruke 
     * @return {@code String} 
     */
    public String ispis(int numIO, int numAVL){
        String ispis = "";
        ispis +="<POS N=" + this.brojUredjaja + " X=" + this.X + " Y=" + this.Y + " H=" + this.altitude + " S=" + this.speed + " D=" + this.direction +
                " IO=" + numIO + " A=" + this.Gtime.split(" ")[0] + " T=" + this.Gtime.split(" ")[1] + " E=" + this.event + " R=" + this.runMode + " KM=" + this.odometer + 
                " SV=" + this.satellites + " SF=0" + ">" + " Poruka=" + numAVL + " IP:" + ip + ":" + port + " ConnectionNumber=" + connectionNumber + 
                " Device<" + brojUredjaja + ">"; 
        return ispis;
    }
    
    /**
     * Zatvaranje DataOutputStream i DataInputStream na uredjaju
     */
    public void zatvoriStreamove(){
        this.udis = null;
        this.udis = null;
    }
    
    public void dodajVrijednostiPozicije(Uredjaj ur){
        this.X = ur.getX();
        this.Y = ur.getY();
        this.direction = ur.getDirection();
        this.altitude = ur.getAltitude();
        this.speed = ur.getSpeed();
        this.Gtime= ur.getGtime();
        this.event = ur.getEvent();
        this.runMode = ur.getRunMode();
        this.satellites = ur.getSatellites();
        this.odometer = ur.getOdometer();
        this.analog1 = ur.getAnalog1();
        this.GsmSignalLevel = ur.getGsmSignalLevel();
        this.batteryLevel = ur.getBatteryLevel(); 
        this.powerSupply = ur.getPowerSupply();
    }
    
    public void resetVrijednostiPozicije(){
        this.X = -999;
        this.Y = -999;
        this.direction = -1;
        this.altitude = -1;
        this.speed = -1;
        this.Gtime= null;
        this.event = -1;
        this.runMode = -1;
        this.satellites = -1;
        this.odometer = -1;
        this.analog1 = -1;
        this.GsmSignalLevel = -1;
        this.batteryLevel = -1; 
        this.powerSupply = -1;
    }
    
    public void dodajInfoIzBaze(Uredjaj ur){
        this.brojUredjaja = ur.getBrojUredjaja();
        this.IMEI_Uredjaj = ur.getIMEI_Uredjaj();
        this.Gtime = ur.getGtime();
        this.brojKartice = ur.getBrojKartice();
        this.nazivGrupe = ur.getNazivGrupe();
        this.GCTip = ur.getGCTip();
        this.regBrVozila = ur.getRegBrVozila();
        this.datumUgradnje = ur.getDatumUgradnje();
        this.IDVozila = ur.getIDVozila();
        this.vrijemeSlanja = ur.getVrijemeSlanja();
        this.vrijemeSlanjaEngineOff = ur.getVrijemeSlanjaEngineOff();
        this.tipUredjaja = ur.getTipUredjaja();
        this.sifraUredjaja = ur.getSifraUredjaja();
        this.Firmware = ur.getFirmware();
        this.PDA = ur.getPDA();
        this.sleepMode = ur.getSleepMode();
        this.identHex = ur.getIdentHex();
        this.IDVozaca = ur.getiDVozaca();
        this.ugaoSlanja = ur.getUgaoSlanja();
        this.distancaSlanja = ur.getDistancaSlanja();
        this.simKarticaProvider = ur.getSimKarticaProvider();
        this.loger = ur.loger;
        this.par = ur.getPar();
    }
    
    
    @Override
    public String toString() {
        return "Uredjaj[" + this.brojUredjaja + " - " + this.tipUredjaja + "] IMEI:" + this.IMEI_Uredjaj + " Grupa:" + this.nazivGrupe + ", GTime: " + this.Gtime + ", FW:" + this.Firmware;
    }
    
    

    
    
    //<editor-fold defaultstate="collapsed" desc="Setter metode">
    
    public void setBrojUredjaja(int brojUredjaja) {
        this.brojUredjaja = brojUredjaja;
    }
    
    public void setIp(String ip) {
        this.ip = ip;
    }
    
    public void setPort(int port) {
        this.port = port;
    }
    
    public void setConnectionNumber(int connectionNumber) {
        this.connectionNumber = connectionNumber;
    }
    
    public void setIMEI_Uredjaj(long IMEI_Uredjaj) {
        this.IMEI_Uredjaj = IMEI_Uredjaj;
    }
    
    public void setGtime(String gtime) {
        this.Gtime = gtime;
    }

    public void setGtimeTest(String GtimeTest) {
        this.GtimeTest = GtimeTest;
    }
    
    public void setGtime(long gtimeMilis){
        long stimeMilis = new java.util.Date().getTime();
//        if ((gtimeMilis - stimeMilis) > par.minuta10){//vrijeme u buducnosti preko 20 minuta (Serversko(.177) vrijeme kasni 3 minute)
//            loger.ispisGreska("Greska, Uredjaj.setGtime(long gtimeMilis)[Uredajaj= " + this.brojUredjaja + "]: Vrijeme u budućnosti " + par.DATUMVRIJEME.format(new Date(gtimeMilis)));
//            this.Gtime = par.DATUMVRIJEME.format(new java.util.Date(gtimeMilis));
//        }else if ((gtimeMilis - stimeMilis) < (-par.minuta10)){
//            loger.ispisGreska("Greska, Uredjaj.setGtime(long gtimeMilis)[Uredajaj= " +this.brojUredjaja + "]: Vrijeme u proslosti " + par.DATUMVRIJEME.format(new Date(gtimeMilis)));
//            this.Gtime = par.DATUMVRIJEME.format(new java.util.Date(gtimeMilis));
//        }else{ 
            this.Gtime = par.DATUMVRIJEME.format(new java.util.Date(gtimeMilis));
//        }
    }
    
    public void setBrojKartice(String brojKartice) {
        this.brojKartice = brojKartice;
    }
    
    public void setNazivGrupe(String nazivGrupe) {
        this.nazivGrupe = nazivGrupe;
    }
    
    public void setgCTip(short gCTip) {
        this.GCTip = gCTip;
    }
    
    public void setRegBrVozila(String regBrVozila) {
        this.regBrVozila = regBrVozila;
    }
    
    public void setDatumUgradnje(String datumUgradnje) {
        this.datumUgradnje = datumUgradnje;
    }
    
    public void setiDVozila(int iDVozila) {
        this.IDVozila = iDVozila;
    }
    
    public void setVrijemeSlanja(int vrijemeSlanja) {
        this.vrijemeSlanja = vrijemeSlanja;
    }
    
    public void setVrijemeSlanjaEngineOff(int vrijemeSlanjaEngineOff) {
        this.vrijemeSlanjaEngineOff = vrijemeSlanjaEngineOff;
    }
    
    public void setTipUredjaja(String tipUredjaja) {
        this.tipUredjaja = tipUredjaja;
    }
    
    public void setSifraUredjaja(String sifraUredjaja) {
        this.sifraUredjaja = sifraUredjaja;
    }
    
    public void setFirmware(String Firmware) {
        this.Firmware = Firmware;
    }
    
    public void setPDA(short PDA) {
        this.PDA = PDA;
    }
    
    public void setSleepMode(short sleepMode) {
        this.sleepMode = sleepMode;
    }
    
    public void setIdentHex(String identHex) {
        this.identHex = identHex;
    }
    
    public void setiDVozaca(short iDVozaca) {
        this.IDVozaca = iDVozaca;
    }
    
    public void setgForceX(float gForceX) {
        this.gForceX = gForceX;
    }

    public void setgForceY(float gForceY) {
        this.gForceY = gForceY;
    }

    public void setgForceZ(float gForceZ) {
        this.gForceZ = gForceZ;
    }
    
    public void setUgaoSlanja(int ugaoSlanja) {
        this.ugaoSlanja = ugaoSlanja;
    }
    
    public void setDistancaSlanja(int distanceSlanja) {
        this.distancaSlanja = distanceSlanja;
    }
    
    public void setSimKarticaProvider(String simKarticaProvider) {
        this.simKarticaProvider = simKarticaProvider;
    }
    
    public void setIDVozila(int IDVozila) {
        this.IDVozila = IDVozila;
    }
    
    public void setIDVozaca(short IDVozaca) {
        this.IDVozaca = IDVozaca;
    }
    
    public void setX(float X) {
        if( X > -180.0000000f && X < 180.0000000f){
            this.X = X;
        }else{            
            loger.ispisGreska("Greska, Uredjaj.setX(double X)[Uredajaj= " + this.brojUredjaja + "]\tKoordinata X je van opsega [-180.0, 180.0]: " + X);
            this.X = -999;
        }
    }
    
    public void setY(float Y) {
        if( Y > -90.000000f && Y < 90.000000f){
            this.Y = Y;
        }else{
            loger.ispisGreska("Greska, Uredjaj.setY(double Y)[Uredajaj= " + this.brojUredjaja + "]\tKoordinata Y je van opsega [-90.0, 90.0]: " + Y);
            this.Y = -999;
        }
    }
    
        /**
         * Funkcija koja dodjeljuje event koji je uzrokovao slanje podataka
         * od uredjaja FMB1YX
         * @param IOEvent koji je prouzrokovao slanje podataka od uredjaja FMB1YX
         */
    public void setEvent(short IOEvent) {
        if (IOEvent == 0){
            if(this.runMode == 1){
                this.event = 2;
            }else if (this.runMode == 0){
                this.event = 3;
            }
        }
        if (IOEvent == 24){
            this.event = 24;
        }
        if (IOEvent == 252){
            this.event = 41;
        }
        if (IOEvent == 67){
            this.event = 42;
        }
        if (satellites == 0){
            this.event = 43;
        }
        if (GsmSignalLevel == 0){
            this.event = 44;
        }
        if (IOEvent == 1 || IOEvent == 239){
            this.event = 11;
        }
    }
    
    public void setEvent(int Event){
        this.event = (short) Event;
    }
    
    /**
     * Funkcija koja dodjeljuje event koji je uzrokovao slanje podataka
     * od uredjaja Queclink GL300N
     * @param tipPoruke String u kojem se nalazi tip poruke iz GL300N uredjaja
     */
    public void setEvent(String tipPoruke){
        if (tipPoruke.contains("GTFRI") || tipPoruke.contains("GTPNL") || tipPoruke.contains("GTNMR")) {
            this.event = 2;
            this.runMode = 1;
        } else if (tipPoruke.contains("GTRTL")) {
            this.event = 0;
        } else if (tipPoruke.contains("GTSPD")) {
            this.event = 8;
            this.runMode = 1;
        } else if (tipPoruke.contains("GTSOS")) {
            this.event = 13;
        }
    }
    
    public void setRunMode(short RunMode) {
        if((RunMode == 0) || (RunMode == 1)){
            this.runMode = RunMode;
        }
        else{
            loger.ispisGreska("Greska, Uredjaj.setRunMode(short RunMode)[Uredajaj= " + this.brojUredjaja + "]Vrijednost RunMode nije ni 1, ni 0, RunMod = " + RunMode);
            this.runMode = -1;
        }
    }
    
    public void setSpeed(float speed){
        this.speed = speed;
    }
    
    public void setSpeed(long Speed, Uredjaj ur) {
        float spd = (float) Speed;
        if(ur.getSpeed() != -1){//
            if(spd < 350){
                float razlikaBrzina = Math.abs(spd - ur.getSpeed());
                if(razlikaBrzina <= 20){
                    this.speed = spd;
                }else{
                    loger.ispisGreska("Greska, Uredjaj.setSpeed(long Speed, Uredjaj ur)[Uredajaj= " + this.brojUredjaja + "] Vozilo je naglo promjenilo brzinu kretanja (Razlika u odnosu na proslu poziciju je " + razlikaBrzina + "km/h)");
                    this.speed = spd;
                }
            }
            else{
                this.speed = -1;
                loger.ispisGreska("Greska, Uredjaj.setSpeed(long Speed, Uredjaj ur)[Uredajaj= " + this.brojUredjaja + "]Vrijednost Speed (IOid = 24) je veca od 350km/h, Speed(IOid = 24) = " + Speed + "km/h");
            }
        }else{
           if(Speed < 350){
               this.speed = spd;
            }
           else{
                this.speed = -1;
                loger.ispisGreska("Greska, Uredjaj.setSpeed(long Speed, Uredjaj ur)[Uredajaj= " + this.brojUredjaja + "]Vrijednost Speed (IOid = 24) je veca od 350km/h, Speed(IOid = 24) = " + Speed + "km/h");
            }
        }
    }
    
    public void setDirection(int direction) {
        if (direction > 360){
            this.direction = -1;
        }else{
            this.direction = direction;
        }
    }
    
    public void setAltitude(int Altitude){
        this.altitude = Altitude;
    }
    
    public void setAltitude(int Altitude, Uredjaj ur) {
        if(ur.getAltitude() != -1){
            //Provjera sa posljednjom lokaciom 
            int razlika = Altitude - ur.getAltitude();
            if(razlika > 200){
                loger.ispisGreska("Greska, Uredjaj.setAltitude(long Altitude, Uredjaj ur)[Uredajaj= " + this.brojUredjaja + "] Vozilo je naglo promjenilo svoju visinu i popelo se sa " + ur.getAltitude() + "m na " + Altitude + "m (Razlika je " + razlika + "m)");
                this.altitude = -1;
            }else if(razlika < -200){
                loger.ispisGreska("Greska, Uredjaj.setAltitude(long Altitude, Uredjaj ur)[Uredajaj= " + this.brojUredjaja + "] Vozilo je naglo promjenilo svoju visinu i spustilo se sa " + ur.getAltitude() + "m na " + Altitude + "m (Razlika je " + razlika + "m)");
                this.altitude = -1;
            }else{
                this.altitude = Altitude;
            }
        }else{
                this.altitude = Altitude;
        }
    }
    
    public void setBatteryLevel(long BatteryLevel) {
        BatteryLevel /= 100.0f;
        this.batteryLevel = BatteryLevel;
    }
    
    public void setBatteryLevel(int BatteryLevel) {
        this.batteryLevel = BatteryLevel;
    }
    
    public void setAnalog1(long Analog1){
        this.analog1 = Analog1;
    }
    
    public void setAnalog1(long Analog1, Uredjaj ur) {
        float an1 = (float) Analog1 / 1000.0f;
        if(ur.getAnalog1() != -1){
            if(an1 >= 0 && an1 <= 65535)
                //if(){//dodatni uslov npr.: Za sondu pragovi koji se koriste da bi se odredilo koliko je goriva u rezervoaru
                    this.analog1 = an1;
                //}else{    }
            else{
                this.analog1 = -1;
                loger.ispisGreska("Greska, Uredjaj.setAnalog1(float Analog1, Uredjaj ur)[Uredjaj= :" + this.brojUredjaja + "] Vrijednost AIN1 je van opsega [0, 65535] - AIN1 (IOid = 9): " + an1);
            }
        }else{
            if(an1 >= 0 && an1 <= 65535)
                this.analog1 = an1;
            else{
                this.analog1 = -1;
                loger.ispisGreska("Greska, Uredjaj.setAnalog1(float Analog1, Uredjaj ur)[Uredjaj= :" + this.brojUredjaja + "] Vrijednost AIN1 je van opsega [0, 65535] - AIN1 (IOid = 9): " + an1);
            }
        }
    }
    
    public void setAnalog2(long Analog2){
        this.analog2 = Analog2;
    }
    
    public void setAnalog2(long Analog2, Uredjaj ur) {
        float an2 = (float) Analog2 / 1000.0f;
        if(ur.getAnalog2() != -1){
            if(an2 >= 0 && an2 <= 65535){
                this.analog2 = an2;
            }else{
                this.analog2 = -1;
                loger.ispisGreska("Greska, Uredjaj.setAnalog2(float Analog2, Uredjaj ur)[Uredjaj= :" + this.brojUredjaja + "] Vrijednost AIN1 je van opsega [0, 65535] - AIN1 (IOid = 9): " + an2);
            }
        }else{
            if(an2 >= 0 && an2 <= 65535){
                this.analog2 = an2;
            }else{
                this.analog2 = -1;
                loger.ispisGreska("Greska, Uredjaj.setAnalog2(float Analog2, Uredjaj ur)[Uredjaj= :" + this.brojUredjaja + "] Vrijednost AIN1 je van opsega [0, 65535] - AIN1 (IOid = 9): " + an2);
            }
        }
    }
    
    public void setFls(int Fls) {
        this.fls = Fls;
    }
    
    public void setFlsLevel1(float FlsLevel1) {
        this.flsLevel1 = FlsLevel1;
    }
    
    public void setFlsLevel2(float FlsLevel2) {
        this.flsLevel2 = FlsLevel2;
    }
    
    public void setFlsDiff1(float FlsDiff1) {
        this.flsDiff1 = FlsDiff1;
    }
    
    public void setFlsDiff2(float FlsDiff2) {
        this.flsDiff2 = FlsDiff2;
    }
    
    public void setFuelTemperature1(float FuelTemperature1) {
        this.fuelTemperature1 = FuelTemperature1;
    }
    
    public void setFuelTemperature2(float FuelTemperature2) {
        this.fuelTemperature2 = FuelTemperature2;
    }
    
    public void setSpeedMax(int SpeedMax) {
        this.speedMax = SpeedMax;
    }
    
    public void setTempSensor1(float TempSensor1) {
        this.tempSensor1 = TempSensor1 / 10.0f;
    }
    
    public void setTempSensor2(float TempSensor2) {
        this.tempSensor2 = TempSensor2 / 10.0f;
    }
    
    public void setTempSensor3(float TempSensor3) {
        this.tempSensor3 = TempSensor3 / 10.0f;
    }
    
    public void setTempSensor4(float TempSensor4) {
        this.tempSensor4 = TempSensor4 / 10.0f;
    }
    
    public void setPowerSupply(long PowerSupply) {
        float ps = (float) PowerSupply;
        ps /= 1000.0f;
        if (ps > 1000.0f){
            ps = 999.99f;
        }
        this.powerSupply = ps;
    }
    
    public void setMileage(double Mileage) {
        this.mileage = Mileage;
    }
    
    public void setOdometer(long Odometer) {
        float odom = (float) Odometer;
        this.odometer = odom;
    }

    public void setGeocode(String geocode) {
        this.geocode = geocode;
    }
    
    public void setJammer(int Jammer) {
        this.jammer = Jammer;
    }
    
    public void setFk_ID_vozac(int fk_ID_vozac) {
        this.fk_ID_vozac = fk_ID_vozac;
    }
    
    public void setRedniBrojPozicije(short RedniBrojPozicije) {
        this.redniBrojPozicije = RedniBrojPozicije;
    }
    
    public void setFk_ID_moje_lokacije(int fk_ID_moje_lokacije) {
        this.fk_ID_moje_lokacije = fk_ID_moje_lokacije;
    }
    
    public void setGCTip(short GCTip) {
        this.GCTip = GCTip;
    }
    
    public void setSatellites(short satellites) {
        this.satellites = satellites;
    }

    public void setGsmSignalLevel(short GsmSignalLevel) {
        if (GsmSignalLevel >= 0 && GsmSignalLevel < 5){
            this.GsmSignalLevel = GsmSignalLevel;
        }
        else{
            loger.ispisGreska("[Uredajaj= " + this.brojUredjaja + "]Vrijednost GsmSignalLevel(IOid = 21) je manja od 0 ili veca od 5, GsmSignalLevel(IOid = 21) = " + GsmSignalLevel);
            this.GsmSignalLevel = -1;
        }
    }
    
    public void setIdent(short Ident) {
        this.Ident = Ident;
    }
    
    public void setUdos(DataOutputStream udos) {
        this.udos = udos;
    }

    public void setUdis(DataInputStream udis) {
        this.udis = udis;
    }

    public void setAccuracy(int accuracy) {
        this.accuracy = accuracy;
    }

    public void setStatusRuteX11(short statusRuteX11) {
        this.statusRuteX11 = statusRuteX11;
    }
    
    //</editor-fold>

    
    //<editor-fold defaultstate="collapsed" desc="Getter metode">
    
    public int getBrojUredjaja() {
        return brojUredjaja;
    }
    

    public String getIp() {
        return ip;
    }


    public int getPort() {
        return port;
    }


    public int getConnectionNumber() {
        return connectionNumber;
    }

        
    public long getIMEI_Uredjaj() {
        return IMEI_Uredjaj;
    }
    
    
    public String getGtime() {
        return Gtime;
    }

    public String getGtimeTest() {
        return GtimeTest;
    }
    
    /**
     * Funkcija koja dijeli Gtime string pomocu {@code .split(" ")} na 2 stringa. Prvi string je Datum Gtime,
     * a drugi string je Vrijeme Gtime. Za {@code int} vrijednost koju prima moze da primi samo vrijednosti
     * {@code 0} ili {@code 1} u suprotnom vraca {@code null}
     * 
     * @param i broj koji oznacava dio stringa kad se izvrsi .split nad Gtime stringom
     * gdje je sa {@code 0} oznacen 1. dio stringa (dio sa datumom) a sa {@code 1}
     * oznacen 2. dio stringa (dio sa vremenom)
     * 
     * @return Datum od Gtime ili Vrijeme od Gtime u zavisnosti od {@code i} ili {@code null} ukoliko
     * je vrijednost {@code i} razlicita od {@code 0} ili {@code 1}
     */
    public String getGtime(int i){
        return Gtime.split(" ")[i];
    }
    
    
    public String getBrojKartice() {
        return brojKartice;
    }
    
    
    public String getNazivGrupe() {
        return nazivGrupe;
    }
    
    
    public String getRegBrVozila() {
        return regBrVozila;
    }
    
    
    public String getDatumUgradnje() {
        return datumUgradnje;
    }
    
    
    public int getiDVozila() {
        return IDVozila;
    }
    
    
    public int getVrijemeSlanja() {
        return vrijemeSlanja;
    }
    
    
    public int getVrijemeSlanjaEngineOff() {
        return vrijemeSlanjaEngineOff;
    }
    
    
    public String getTipUredjaja() {
        return tipUredjaja;
    }
    
    
    public String getSifraUredjaja() {
        return sifraUredjaja;
    }
    
    
    public String getFirmware() {
        return Firmware;
    }
    
    
    public short getPDA() {
        return PDA;
    }
    

    public float getgForceX() {
        return gForceX;
    }
    
    
    public float getgForceY() {
        return gForceY;
    }

    
    public float getgForceZ() {
        return gForceZ;
    }
    
    
    public short getSleepMode() {
        return sleepMode;
    }
    
    
    public String getIdentHex() {
        return identHex;
    }
    
    
    public short getiDVozaca() {
        return IDVozaca;
    }
    
    
    public int getUgaoSlanja() {
        return ugaoSlanja;
    }
    
    
    public int getDistancaSlanja() {
        return distancaSlanja;
    }
    
    
    public String getSimKarticaProvider() {
        return simKarticaProvider;
    }
    

    public int getIDVozila() {
        return IDVozila;
    }


    public short getIDVozaca() {
        return IDVozaca;
    }


    public float getX() {
        return X;
    }


    public float getY() {
        return Y;
    }


    public short getEvent() {
        return event;
    }


    public short getRunMode() {
        return runMode;
    }


    public float getSpeed() {
        return speed;
    }


    public int getDirection() {
        return direction;
    }


    public int getAltitude() {
        return altitude;
    }


    public float getBatteryLevel() {
        return batteryLevel;
    }


    public float getAnalog1() {
        return analog1;
    }


    public float getAnalog2() {
        return analog2;
    }


    public int getFls() {
        return fls;
    }


    public float getFlsLevel1() {
        return flsLevel1;
    }


    public float getFlsLevel2() {
        return flsLevel2;
    }


    public float getFlsDiff1() {
        return flsDiff1;
    }


    public float getFlsDiff2() {
        return flsDiff2;
    }


    public float getFuelTemperature1() {
        return fuelTemperature1;
    }


    public float getFuelTemperature2() {
        return fuelTemperature2;
    }


    public int getSpeedMax() {
        return speedMax;
    }


    public float getTempSensor1() {
        return tempSensor1;
    }


    public float getTempSensor2() {
        return tempSensor2;
    }


    public float getTempSensor3() {
        return tempSensor3;
    }


    public float getTempSensor4() {
        return tempSensor4;
    }


    public float getPowerSupply() {
        return powerSupply;
    }


    public double getMileage() {
        return mileage;
    }


    public float getOdometer() {
        return odometer;
    }


    public int getJammer() {
        return jammer;
    }


    public int getFk_ID_vozac() {
        return fk_ID_vozac;
    }


    public short getRedniBrojPozicije() {
        return redniBrojPozicije;
    }


    public int getFk_ID_moje_lokacije() {
        return fk_ID_moje_lokacije;
    }


    public short getGCTip() {
        return GCTip;
    }


    public short getSatellites() {
        return satellites;
    }


    public short getIdent() {
        return Ident;
    }
    

    public DataOutputStream getUdos() {
        return udos;
    }

    
    public DataInputStream getUdis() {
        return udis;
    }
    
    public short getGsmSignalLevel() {
        return GsmSignalLevel;
    }
    

    public Parametri getPar() {
        return par;
    }
    
    
    public String getGeocode() {
        return geocode;
    }
    

    public int getAccuracy() {
        return accuracy;
    }
    
    
    public short getStatusRuteX11() {
        return statusRuteX11;
    }

    
    
    //</editor-fold>

    

    
    
}    
