/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guiaplikacija;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

/**
 *
 * @author branko.salabalija
 */
public class Pozicija {//staviti pocetne vrijednosti na null
    
    
    private int brojUredjaja;
    private String imei;
    private double X;
    private double Y;
    private long Gtime;//String
    private short Event;
    private short RunMode;
    private float Speed;
    private int Direction;
    private int Altitude;
    private short Satellites;
    private short GsmSignalLevel;
    private float Accuracy;
    private int BatteryLevel;
    private float Analog1;
    private float Analog2;
    private float GForceX;
    private float GForceY;
    private float GForceZ;
    private float FlsLevel1;
    private float FlsLevel2;
    private int Fls;
    private float FlsDiff1;
    private float FlsDiff2;
    private int SpeedMax;
    private float TempSensor1;
    private float TempSensor2;
    private float TempSensor3;
    private float TempSensor4;
    private float FuelTemperature1;
    private float FuelTemperature2;
    private float PowerSupply;
    private double Mileage;
    private float Odometer;
    private String Geocode;
    private long Ctime;//String
    private long DiffTime;
    private String Jammer;
    private int fk_ID_vozac;
    private short Ident;
    private short Tmp1;
    private short Tmp2;
    private int Tmp3;
    private float Tmp4;
    private short RedniBrojPozicije;
    private int fk_ID_moje_lokacije;
    
        
    public Pozicija() {
    }
        
    
    public Pozicija( int nazivUredjaj, String imei, double Wx, double Wy, long Gtime, short Event, short RunMode, float Speed, int Direct, int Altitude, short Satellites, short GsmSignalLevel, float Accuracy, int BatteryLevel, float Analog1, float Analog2, float GForceX, float GForceY, float GForceZ, int Fls, float FlsLevel1, float FlsLevel2, float TempSensor1, float TempSensor2, float TempSensor3, float TempSensor4, float FuelTemperature1, float FuelTemperature2, float PowerSupply, float Mileage, float Odometer, String Geocode, long Ctime, long DiffTime, String Jammer, int fk_ID_vozac, short Ident, short Tmp1, short Tmp2, int Tmp3, float Tmp4, short RedniBrojPozicije, int fk_ID_moje_lokacije, String ID_raw_data) {
        this.brojUredjaja = nazivUredjaj;
        this.imei = imei;
        this.X = Wx;
        this.Y = Wy;
        this.Gtime = Gtime;
        this.Event = Event;
        this.RunMode = RunMode;
        this.Speed = Speed;
        this.Direction = Direct;
        this.Altitude = Altitude;
        this.Satellites = Satellites;
        this.GsmSignalLevel = GsmSignalLevel;
        this.Accuracy = Accuracy;
        this.BatteryLevel = BatteryLevel;
        this.Analog1 = Analog1;
        this.Analog2 = Analog2;
        this.GForceX = GForceX;
        this.GForceY = GForceY;
        this.GForceZ = GForceZ;
        this.Fls = Fls;
        this.FlsLevel1 = FlsLevel1;
        this.FlsLevel2 = FlsLevel2;
        this.TempSensor1 = TempSensor1;
        this.TempSensor2 = TempSensor2;
        this.TempSensor3 = TempSensor3;
        this.TempSensor4 = TempSensor4;
        this.FuelTemperature1 = FuelTemperature1;
        this.FuelTemperature2 = FuelTemperature2;
        this.PowerSupply = PowerSupply;
        this.Mileage = Mileage;
        this.Odometer = Odometer;
        this.Geocode = Geocode;
        this.Ctime = Ctime;
        this.DiffTime = DiffTime;
        this.Jammer = Jammer;
        this.fk_ID_vozac = fk_ID_vozac;
        this.Ident = Ident;
        this.Tmp1 = Tmp1;
        this.Tmp2 = Tmp2;
        this.Tmp3 = Tmp3;
        this.Tmp4 = Tmp4;
        this.RedniBrojPozicije = RedniBrojPozicije;
        this.fk_ID_moje_lokacije = fk_ID_moje_lokacije;
    }
    
    public boolean UpsiUTabelu(Connection con) throws SQLException {
        Statement call = null;
        call = con.createStatement();
        
        String str = "{CALL `java2db_FM_Teltonika` (" + this.brojUredjaja + "," + this.X + "," + this.Y + ",'" + Parametri.DATUMVRIJEME.format(new Date(this.Gtime)) + 
                "'," + this.Event + "," + this.RunMode + "," + this.Speed + "," + this.Direction + "," + this.Altitude + "," + this.Satellites + "," +
                this.GsmSignalLevel + "," + this.Accuracy + "," + this.BatteryLevel + "," + this.Analog1 + "," + this.Analog2 + "," + this.GForceX + "," + 
                this.GForceY + "," + this.GForceZ + "," + this.FlsLevel1 + "," + this.FlsLevel2 + "," + this.Mileage + "," + this.Odometer + "," +
                "'BanjaLuka'" + "," + this.fk_ID_vozac + "," + this.Tmp1 + "," + this.Tmp2 + "," + this.Tmp3 + "," + this.Tmp4 + "," + this.Fls + "," +
                this.FlsDiff1 + "," + this.FlsDiff2 + "," + this.SpeedMax + "," + this.fk_ID_moje_lokacije + "," + this.Ident + "," + this.TempSensor1 +
                "," + this.TempSensor2 + "," + this.TempSensor3 + "," + this.TempSensor4 + "," + this.FuelTemperature1 + "," + this.FuelTemperature2 +
                "," + this.PowerSupply + "," + this.Jammer + "," + this.RedniBrojPozicije + ")}";
        
        return call.execute(str);
    }
        
    
    @Override
    public String toString() {
        return "Vrijednosti GPS{" + ", Uredjaj=" + brojUredjaja + ",\n Wx=" + X + ", Wy=" + Y + ", Gtime=" + Parametri.DATUMVRIJEME.format(new Date(Gtime)) + ", Event=" + Event + ", RunMode=" + RunMode + ", Speed=" + Speed + ", Direct=" + Direction + ", Altitude=" + Altitude + ",\n Satellites=" + Satellites + ", GsmSignalLevel=" + GsmSignalLevel + ", Accuracy=" + Accuracy + ",\n BatteryLevel=" + BatteryLevel + ", Analog1=" + Analog1 + ", Analog2=" + Analog2 + ", GForceX=" + GForceX + ", GForceY=" + GForceY + ", GForceZ=" + GForceZ + ", FlsLevel1=" + FlsLevel1 + ", FlsLevel2=" + FlsLevel2 + ",\n TempSensor1=" + TempSensor1 + ", TempSensor2=" + TempSensor2 + ", TempSensor3=" + TempSensor3 + ", TempSensor4=" + TempSensor4 + ", FuelTemperature1=" + FuelTemperature1 + ", FuelTemperature2=" + FuelTemperature2 + ", PowerSupply=" + PowerSupply + ",\n Mileage=" + Mileage + ", Odometer=" + Odometer + ", Geocode=" + Geocode + ", Ctime=" + Ctime + ", DiffTime=" + DiffTime + ", Jammer=" + Jammer + ",\n fk_ID_vozac=" + fk_ID_vozac + ", Ident=" + Ident + ", Tmp1=" + Tmp1 + ", Tmp2=" + Tmp2 + ", Tmp3=" + Tmp3 + ", Tmp4=" + Tmp4 + ", RedniBrojPozicije=" + RedniBrojPozicije + ", fk_ID_moje_lokacije=" + fk_ID_moje_lokacije + '}';
    }
    
    public String ispis(int numIO){
        String ispis = "";
        ispis += "<POS N=" + this.brojUredjaja + " X=" + this.X + " Y=" + this.Y + " H=" + this.Altitude + " S=" + this.Speed + " D=" + this.Direction +
                    " IO=" + numIO + " A=" + (Parametri.DATUMVRIJEME.format(new Date(this.Gtime))) + " T=" + (Parametri.DATUMVRIJEME.format(new Date(this.Gtime))) +
                    " E=" + this.Event + " R=" + this.RunMode + " KM=" + this.Odometer + " SV=" + this.Satellites + " SF=0" + ">";
        return ispis; 
    }
    
//<editor-fold defaultstate="collapsed" desc="Getter i Setter metode">
    
    public int getBrojUredjaja() {
        return brojUredjaja;
    }
    
    public void setBrojUredjaja(int Uredjaj) {
        this.brojUredjaja = Uredjaj;
    }
    
    public double getX() {
        return X;
    }
    
    public void setX(double Wx) {
        this.X = Wx;
    }
    
    public double getY() {
        return Y;
    }
    
    public void setY(double Wy) {
        this.Y = Wy;
    }
    
    public long getGtime() {
        return Gtime;
    }
    
    public void setGtime(long Gtime) {
        long tren = new Date().getTime();
        if((Gtime > tren) || (Gtime < (tren - 1200000)))
        this.Gtime = Gtime;
    }
    
    public short getEvent() {
        return Event;
    }
    
    public void setEvent(short Event) {
        this.Event = Event;
    }
    
    public short getRunMode() {
        return RunMode;
    }
    
    public void setRunMode(short RunMode) {
        this.RunMode = RunMode;
    }
    
    public float getSpeed() {
        return Speed;
    }
    
    public void setSpeed(float Speed) {
        this.Speed = Speed;
    }
    
    public int getDirection() {
        return Direction;
    }
    
    public void setDirection(int Direction) {
        this.Direction = Direction;
    }
    
    public int getAltitude() {
        return Altitude;
    }
    
    public void setAltitude(int Altitude) {
        this.Altitude = Altitude;
    }
    
    public short getSatellites() {
        return Satellites;
    }
    
    public void setSatellites(short Satellites) {
        this.Satellites = Satellites;
    }
    
    public short getGsmSignalLevel() {
        return GsmSignalLevel;
    }
    
    public void setGsmSignalLevel(short GsmSignalLevel) {
        this.GsmSignalLevel = GsmSignalLevel;
    }
    
    public float getAccuracy() {
        return Accuracy;
    }
    
    public void setAccuracy(float Accuracy) {
        this.Accuracy = Accuracy;
    }
    
    public int getBatteryLevel() {
        return BatteryLevel;
    }
    
    public void setBatteryLevel(int BatteryLevel) {
        this.BatteryLevel = BatteryLevel;
    }
    
    public float getAnalog1() {
        return Analog1;
    }
    
    public void setAnalog1(float Analog1) {
        this.Analog1 = Analog1;
    }
    
    public float getAnalog2() {
        return Analog2;
    }
    
    public void setAnalog2(float Analog2) {
        this.Analog2 = Analog2;
    }
    
    public float getGForceX() {
        return GForceX;
    }
    
    public void setGForceX(float GForceX) {
        this.GForceX = GForceX;
    }
    
    public float getGForceY() {
        return GForceY;
    }
    
    public void setGForceY(float GForceY) {
        this.GForceY = GForceY;
    }
    
    public float getGForceZ() {
        return GForceZ;
    }
    
    public void setGForceZ(float GForceZ) {
        this.GForceZ = GForceZ;
    }
    
    public float getFlsLevel1() {
        return FlsLevel1;
    }
    
    public void setFlsLevel1(float FlsLevel1) {
        this.FlsLevel1 = FlsLevel1;
    }
    
    public float getFlsLevel2() {
        return FlsLevel2;
    }
    
    public void setFlsLevel2(float FlsLevel2) {
        this.FlsLevel2 = FlsLevel2;
    }
    
    public float getTempSensor1() {
        return TempSensor1;
    }
    
    public void setTempSensor1(float TempSensor1) {
        this.TempSensor1 = TempSensor1;
    }
    
    public float getTempSensor2() {
        return TempSensor2;
    }
    
    public void setTempSensor2(float TempSensor2) {
        this.TempSensor2 = TempSensor2;
    }
    
    public float getTempSensor3() {
        return TempSensor3;
    }
    
    public void setTempSensor3(float TempSensor3) {
        this.TempSensor3 = TempSensor3;
    }
    
    public float getTempSensor4() {
        return TempSensor4;
    }
    
    public void setTempSensor4(float TempSensor4) {
        this.TempSensor4 = TempSensor4;
    }
    
    public float getFuelTemperature1() {
        return FuelTemperature1;
    }
    
    public void setFuelTemperature1(float FuelTemperature1) {
        this.FuelTemperature1 = FuelTemperature1;
    }
    
    public float getFuelTemperature2() {
        return FuelTemperature2;
    }
    
    public void setFuelTemperature2(float FuelTemperature2) {
        this.FuelTemperature2 = FuelTemperature2;
    }
    
    public float getPowerSupply() {
        return PowerSupply;
    }
    
    public void setPowerSupply(float PowerSupply) {
        this.PowerSupply = PowerSupply;
    }
    
    public double getMileage() {
        return Mileage;
    }
    
    public void setMileage(double Mileage) {
        this.Mileage = Mileage;
    }
    
    public float getOdometer() {
        return Odometer;
    }
    
    public void setOdometer(float Odometer) {
        this.Odometer = Odometer;
    }
    
    public String getGeocode() {
        return Geocode;
    }
    
    public void setGeocode(String Geocode) {
        this.Geocode = Geocode;
    }
    
    public long getCtime() {
        return Ctime;
    }
    
    public void setCtime(long Ctime) {
        this.Ctime = Ctime;
    }
    
    public long getDiffTime() {
        return DiffTime;
    }
    
    public void setDiffTime(long DiffTime) {
        this.DiffTime = DiffTime;
    }
    
    public String getJammer() {
        return Jammer;
    }
    
    public void setJammer(String Jammer) {
        this.Jammer = Jammer;
    }
    
    public int getFk_ID_vozac() {
        return fk_ID_vozac;
    }
    
    public void setFk_ID_vozac(int fk_ID_vozac) {
        this.fk_ID_vozac = fk_ID_vozac;
    }
    
    public short getIdent() {
        return Ident;
    }
    
    public void setIdent(short Ident) {
        this.Ident = Ident;
    }
    
    public short getTmp1() {
        return Tmp1;
    }
    
    public void setTmp1(short Tmp1) {
        this.Tmp1 = Tmp1;
    }
    
    public short getTmp2() {
        return Tmp2;
    }
    
    public void setTmp2(short Tmp2) {
        this.Tmp2 = Tmp2;
    }
    
    public int getTmp3() {
        return Tmp3;
    }
    
    public void setTmp3(int Tmp3) {
        this.Tmp3 = Tmp3;
    }
    
    public float getTmp4() {
        return Tmp4;
    }
    
    public void setTmp4(float Tmp4) {
        this.Tmp4 = Tmp4;
    }
    
    public short getRedniBrojPozicije() {
        return RedniBrojPozicije;
    }
    
    public void setRedniBrojPozicije(short RedniBrojPozicije) {
        this.RedniBrojPozicije = RedniBrojPozicije;
    }
    
    public int getFk_ID_moje_lokacije() {
        return fk_ID_moje_lokacije;
    }
    
    public void setFk_ID_moje_lokacije(int fk_ID_moje_lokacije) {
        this.fk_ID_moje_lokacije = fk_ID_moje_lokacije;
    }
    
    public String getImei() {
        return imei;
    }
    
    public void setImei(String imei) {
        this.imei = imei;
    }
    
    public int getFls() {
        return Fls;
    }
    
    public void setFls(int Fls) {
        this.Fls = Fls;
    }
//</editor-fold>
    
}
