
package guiaplikacija;

import java.net.*; 
import java.io.*; 
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
        
public class ServerKlasa extends Thread{

    private Socket           socket   = null; 
    private ServerSocket     server   = null; 
    private DataInputStream  sdis      = null;
    private DataOutputStream sdos      = null;
    private boolean flag = true;
    private int port = 0;
    private int redniBroj_Uredjaja_U_Listi = -1;
    
    private static int clientCount = 1;
    
    private final Parametri parametri;
    private List<Uredjaj> uredjaji_IzBaze;
    private Date serverStartTime;
    private Logeri loger = null;
    
    
    
    
    public ServerKlasa(int port, Logeri lg, List<Uredjaj> uredjaji, Parametri parametri){
        loger = lg;
        uredjaji_IzBaze = uredjaji;//
        this.parametri = parametri;
        this.port = port;
    }
    
    @Override
    public void run(){
        
        serverStartTime = new Date();
//         starts server and waits for a connection 
        try
        {
            server = new ServerSocket(port);
            System.out.println("Server pokrenut u " + parametri.DATUMVRIJEME.format(serverStartTime));
            loger.ispisPoruka("\n-----------------------------------------------------\n"
                            + "Server pokrenut u " + parametri.DATUMVRIJEME.format(serverStartTime));
            loger.ispisPozicija("\n---------------------------------------------------\n"
                            + "Server pokrenut u " + parametri.DATUMVRIJEME.format(serverStartTime));
            loger.ispisGreska("\n-----------------------------------------------------\n"
                            + "Server pokrenut u " + parametri.DATUMVRIJEME.format(serverStartTime));
            while (flag && clientCount < 200){
                System.out.println("Cekanje na klijenta br." + clientCount + "  ...");
                socket = server.accept();
                
                System.out.println("Klijent " + socket + " konektovan u " + parametri.DATUMVRIJEME.format(new Date())); 
                
                // takes input from the client socket 
                sdis = new DataInputStream(socket.getInputStream());
                sdos = new DataOutputStream(socket.getOutputStream());
                
                System.out.println("Dodavanje Threada klijentu");
                Thread t = new ClientHandler(socket, sdis, sdos);
                t.start();
                clientCount++;
                System.out.println("Pokrenut thread za klijenta " + socket);
            }
            
            if(!flag){
            System.out.println("Gasenje Servera");
            }
        } 
        catch(Exception i) 
        { 
            System.out.println("Port je vec zauzet \n" + i);
            loger.ispisGreska("Greska, ServerKlasa.ServerKlasa(int port), Port je vec zauzet\n\t" + i.toString());

        }
    }
   
    
    
    /**
     * Klasa koja pravi nit za svaki uredjaj koji je konektovan na server
     */
    public class ClientHandler extends Thread{
        final DataInputStream dis;  
        final DataOutputStream dos;
        final Socket s;
        final String cliName="Client #" + clientCount;
        Uredjaj uredjaj;
        Uredjaj uredjaj_fresh;
        String raw="";
        List<Byte> teltonica_AVLdata_for_CRC16 = new ArrayList<>();
        boolean threadFlag = true, avlFlag = false, gcFlag = true;
        int brojPoruka = 0, p=0;
        private List<String> pp_pozicije; // ponovo poslata pozicija
        
        public ClientHandler(Socket s, DataInputStream sdis, DataOutputStream sdos){
            this.s = s;
            this.dis = sdis;
            this.dos = sdos;
            this.uredjaj = new Uredjaj(sdis, sdos, s.getInetAddress().getHostAddress(), s.getPort(), loger, parametri);
            this.uredjaj_fresh = uredjaj;
            pp_pozicije = new ArrayList<>();
        }
        
        @Override
        public void run(){
            String poruka = "";
            try{
                while (threadFlag){

                    byte[] prijem = citanjeSaUlaza(2); //Prva dva bajta od uredjaja koji se konektuje

                    if (prijem != null){

                        //provjera za Teltonika uredjaje
                        if(prijem[0] == 0 && prijem[1] == 15){
                            //Teltonica uredjaji
                            //Provjera IMEI uredjaja
                            String imei = Long.toString(citanjeIMEIa(15)); //Citanje imei pretvoriti u String iz long-a

                            boolean isTrue = imeiCheck(imei);
                            if (isTrue){
                                //odobri konekciju ako je IMEI validan
                                odobravanjeKonekcijeTeltonika_FMB1YX(isTrue);
                                readAVL_Teltonika();
                            }else{
                                odobravanjeKonekcijeTeltonika_FMB1YX(isTrue);
                                System.out.println("Greska, uredjaj nije na listi uredjaja na serveru");
                                loger.ispisGreska("Greska, uredjaj nije na listi uredjaja na serveru");
                                break;//iskoci iz petlje i zatvori thread.
                            }
                        }
                        //Provjera za GL300N uredjaje
                        else if ((char) prijem[0] == '+'){
                                //Queclink uredjaji
                                raw = "" + (char) prijem[0] + "" + (char) prijem[1];
                                poruka = citanjeSaUlaza();
                                if (imeiCheck(poruka.split(",")[2])){
                                    loger.ispisPoruka("RawData ["+ uredjaj.getBrojUredjaja() + "-" + uredjaj.getTipUredjaja() +"]=" + raw);
                                    if((char) prijem[1] == 'A'){
                                        //+ACK: acknowlegement
                                        odobravanjeKonekcije_GL300N(poruka);
                                    }
                                    else if ((char) prijem[1] == 'R' || (char) prijem[1] == 'B'){
                                        //+RESP: response i +BUFF: istresanje
                                        readAVL_GL300N(poruka);
                                    }
                                }
                        }
                    }
                    else {
                        System.out.println("Greska, f-ja citanjeSaUlazaUnsigned(2) prijem = " + prijem[0] + prijem[1] + ",\t" + parametri.DATUMVRIJEME.format(new Date()));
                        loger.ispisGreska("Greska, f-ja citanjeSaUlazaUnsigned(2) prijem = " + prijem[0] + prijem[1] + ",\t" + parametri.DATUMVRIJEME.format(new Date()));
                    }
                }
            }catch(Exception e){
                System.out.println("Greska, ClientHadler.run() za poruku "+ poruka +"\t" + e.toString());
                loger.ispisGreska("Greska, ClientHadler.run() za poruku "+ poruka +"\t" + e.toString());
            }
            
            
            try
                { 
                    // closing resources 
                    this.dis.close(); 
                    this.dos.close();
                    uredjaj.zatvoriStreamove();
                    clientCount--;

                }catch(Exception e){
                    System.out.println("Uhvacen Exception u thread-u clijentHandler prilikom zatvaranja resursa " + parametri.DATUMVRIJEME.format(new Date()) + "\n" + e);
                    loger.ispisGreska("Uhvacen Exception u thread-u clijentHandler prilikom zatvaranja resursa " + e.toString());
                    
                }
        }
        
        /**
         * Funkcija koja cita bajtove sa Input stream-a i pretvara ih u broj tipa
         * {@code long} koji predstavlja IMEI uredjaja
         * 
         * @param duzinaNiza broj bajtova koji ce se procitati sa Input stream-a
         * @return {@code long} broj koji predstavlja IMEI uredjaja
         */
        private synchronized long citanjeIMEIa(int duzinaNiza){
            long back = -1;
            try{
                byte[] b = new byte[duzinaNiza];
                long ucitan = dis.read(b);
                if (ucitan != -1){
                    back = 0;
                    for  (int i=0; i < b.length; i++){
                        String temp2 = leadingZero(Integer.toHexString((int)(b[i]) & 0xFF));
                        raw += "" + temp2;
                        back +=  (Integer.valueOf(temp2) - 30) * Math.pow(10, --duzinaNiza);
                        if (avlFlag){
                            teltonica_AVLdata_for_CRC16.add(b[i]);
                        }
                    }
                    raw += " ";
                }else{
                    return -1;
                }
                return back;//imei
            }catch(Exception e){
                System.out.println("Greska, ServerKlasa.citanjeIMEIa(int duzinaNiza)[Uredajaj= " + uredjaj.getBrojUredjaja() + "]: " + e.toString());
                loger.ispisGreska("Greska, ServerKlasa.citanjeIMEIa(int duzinaNiza)[Uredajaj= " + uredjaj.getBrojUredjaja() + "]: " + e.toString());
            }
            return -1;
            
        }
        
        /**
         * Funkcija koja cita sa input stream-a uz pomoc buffera velicina 
         * <strong>1B, 2B, 4B, 8B (B - bajtova)</strong>. Vraca niz bajtova
         * {@code byte[]} procitani sa strema ili {@code -1} ako je {@code ucitan == EOF}.
         * 
         * @param duzinaNiza Broj bajtova koji ce se procitati sa stream-a
         * @return niz bajtova ({@code byte[]}) procitaih sa Input stream-a 
         */
        private synchronized byte[] citanjeSaUlaza(int duzinaNiza){
            byte[] b = null;
            try{
                b = new byte[duzinaNiza];
                int ucitan = dis.read(b); //citanje sa stream-a bajt po bajt.
                if (ucitan != -1){ // provjera da li je procitan EOF, tj. -1
                    for  (int i=0; i < b.length; i++){
                        String temp2 = leadingZero(Integer.toHexString((int)(b[i]) & 0xFF));
//                        temp += "" + temp2;
                        raw += "" + temp2;
//                            System.out.println("Raw data: " + raw);
                        if (avlFlag){
                            teltonica_AVLdata_for_CRC16.add(b[i]);
                        }
                    }
                    raw += " ";
                }else{
                    return null;// return null
                }
                
            }catch (Exception e){
                System.out.println("Greska, citanjesSaUlaza("+ duzinaNiza +")[Uredajaj= " + uredjaj.getBrojUredjaja() + "]: \n\t" + e.toString());
                loger.ispisGreska("Greska, citanjesSaUlaza("+ duzinaNiza +")[Uredajaj= " + uredjaj.getBrojUredjaja() + "]: \n\t" + e.toString());
            }
            
            return b;
        }
        
        /**
         * Funkcija koja cita bajtove sa input stream-a uredjaja Queclink GL300N.
         * Funkcija vraca poruku od uredjaja kao {@code String} sa Input stream-a ili
         * {@code null} ako je procitan EOF. Funkcija se zaustavlja kad primi znak
         * {@code '$'} koji oznacava kraj poruke ili ako je broj procitanih karaktera
         * veci od 500
         * 
         * @return poruku od uredjaja kao {@code String} sa Input stream-a ili {@code null} 
         * ako je procitan EOF.
         */
        private synchronized String citanjeSaUlaza (){ //prepraviti ime funkcije
//            String[] back = new String[2];
            String back = "";
            try {
                int i = 0;
                int ucitan = 0;
                String tmp = "";
                
                //2b i 
                
                while (ucitan != (-1) && ucitan != 36){         //citaj podatke sa input stream-a sve kod ne procita EOF (-1) ili dolar znak (36 == (int) '$')
                    ucitan = dis.read();                        //procitaj sljedeci bajt
                    raw += "" + (char) ucitan;                  //snimi u raw string
                    back += "" + (char) ucitan;
                    if(ucitan == (-1)){
                        //greska, ucitan je EOF
                        return back = null;
                    }
                    if(i++ > 500){
                        //greska, poruka duza od  500 karaktera
                        break;
                    }
                }
            } catch (Exception e) {
                
                System.out.println("Greska, citanjeRawSaUlaza()[Uredajaj= " + uredjaj.getBrojUredjaja() + "]: \n\t" + e.toString());
                loger.ispisGreska("Greska, citanjeRawSaUlaza()[Uredajaj= " + uredjaj.getBrojUredjaja() + "]: \n\t" + e.toString());
            
            }
            return back;
        }
        
        /**
         * 
         * Koristi se za provjeru IMEI-a koji je poslan od strane Teltonica uredjaja.
         * Funkcija vraca {@code true} ako je IMEI postojeci i salje
         * uredjaju vrijednost {@code 0x01}, a {@code false} ako je 
         * IMEI ne postoji i salje uredjaju vrijednost {@code 0x00}
         * 
         * @param duz_imei broj koji oznacava kolika je duzina IMEI-a (obicno je to 15)
         * @return {@code true} ako je IMEI postojeci, {@code false} ako IMEI 
         * ne postoji
         */
        private boolean imeiCheck(String imeiPrijem){
            try{
                if (imeiPrijem.length() != 0){
                    long imei = Long.parseLong(imeiPrijem);
                    
                    Uredjaj ured = null;
                    
                    for(int i=0; i<uredjaji_IzBaze.size(); i++){
                        ured = uredjaji_IzBaze.get(i);
                        if(ured.getIMEI_Uredjaj() == imei){
                            
                            ured.dodajIpPortInfo(uredjaj);//Prebaci Ip. Port, dis, dos u uredjaj sa liste
                            uredjaj_fresh = ured;//prekopiraj proslu lokaciju u lokalni uredjaj_fresh radi provjere kad doje nova pozicija
                            uredjaj.dodajInfoIzBaze(ured);
                            redniBroj_Uredjaja_U_Listi = i;//zapamti na kom mjestu u listi se nalazi uredjaj
                            
                            this.setName(""+ uredjaj.getBrojUredjaja() +"-"+ uredjaj.getTipUredjaja()); //Setovanje imena Thread-a
                            return true;
                        }
                    }
                }else{
                    return false;
                }
            }catch(Exception e){
                System.out.println("Greska, ServerKlasa.ImeiCheck()[Uredajaj= " + uredjaj.getBrojUredjaja() + "]: \n\t" + e.toString());
                loger.ispisGreska("Greska, ServerKlasa.ImeiCheck()[Uredajaj= " + uredjaj.getBrojUredjaja() + "]: \n\t" + e.toString());
            }
            return false;
        }
        
        /**
         * Zaustavljanje treda ClientHandler
         */
        public void stopClientHandler(){
            threadFlag = false;
        }
        
        /**
         * Funkcija koja pretvara niz bajtova u {@code long}
         * @param prijem niz bajtova koji je primljen sa input stream-a od uredjaja
         * @return vrijednost niza kao jedan broj tipa {@code long}
         */
        public long parseTeltonikaLong(byte[] prijem){
            long parsiran = 0;
            String temp = "";
            for (int i=0; i<prijem.length; i++){
                String temp2 = leadingZero(Integer.toHexString((int)(prijem[i]) & 0xFF));
                temp += "" + temp2;
            }
            parsiran = Long.parseLong(temp,16);                
            return parsiran;
        }
        
        
        public void odobravanjeKonekcijeTeltonika_FMB1YX(boolean bool){
            try{
                if(bool){
                    dos.writeByte(1);
                    dos.flush();
                }else{
                    dos.writeByte(0);
                    dos.flush();
                }
            }catch(Exception e){
                System.out.println("Greska, ServerKlasa.odobriKonekcijuTeltonika(boolean bool)[Uredajaj= " + uredjaj.getBrojUredjaja() + "]: \n\t" + e.toString());
                loger.ispisGreska("Greska, ServerKlasa.odobriKonekcijuTeltonika(boolean bool)[Uredajaj= " + uredjaj.getBrojUredjaja() + "]: \n\t" + e.toString());
            }
        }
        
        /**
         * Provjerava da li je trenutna pozicija vec jednom poslana tako sto uporedjuje
         * trenutni GTime sa GTime-om poslanih pozicija. Ako se GTime trenutne pozicije
         * poklapa sa GTime-om iz liste onda je trenutna pozicija vec jednom poslana i ODOmetar
         * trenutne pozicije se setuje na 0 (kako nebi doslo do uvecanja ukupne kilometraze u bazi)
         * 
         * @param uredjaj Uredjaj za koji se provjerava GTime
         */
        public void provjera_pristiglog_gtime(Uredjaj uredjaj){
            String urGtime = uredjaj.getGtimeTest();
            for(int i=0; i<pp_pozicije.size(); i++){
                if (urGtime.equals(pp_pozicije.get(i))){
                    uredjaj.setOdometer(0);
                    loger.ispisGreska("Greska, Uredjaj= " + uredjaj.getBrojUredjaja() + " je ponovo poslao poziciju sa istim GTIME= " + uredjaj.getGtimeTest() + ". ODOmetar setovan na 0");
                    break;
                }
            }

            //upisuje se uredjaj u listu pp_pozicija
            if(pp_pozicije.size() > 20){
                //p=0;
                pp_pozicije.remove(0); //izbrisi najstariju poziciju
            }            
            //pp_pozicije.set(p++, urGtime);
            pp_pozicije.add(urGtime);
            loger.ispisPoruka("Upisano je " + urGtime + " u listu pp_pozicije ");
            //p++;
            
        }
        
        //----------------------------------------------------------------------
        //prijem podataka Teltonica---------------------------------------------
        
        /**
         * Prijem AVL podataka sa TELTONICA input stream-a
         */
        private void readAVL_Teltonika(){
            int df=0, numOD1=0, numOD2=0, IOEvent=0;
            byte[] buffer = null;
            List<String> sqlUpit = new ArrayList<>();
            
            try{
                uredjaj.setConnectionNumber(clientCount - 1);
                //4 Zeros
                while(citanjeSaUlaza(1)[0] != -1){
                    buffer = new byte[3];
                    buffer = citanjeSaUlaza(3);
                    System.out.print("4 zero: ");
                    for(byte b : buffer){
                        System.out.print(b);
                    }


                    //Data Field length
                    buffer = new byte[4];
                    buffer = citanjeSaUlaza(4);
                    df = (int) parseTeltonikaLong(buffer);
                    System.out.println("\nData field length: " + df);



                    //Pocetak AVL data--------------------------------------------------


                    //Codec ID
                    avlFlag = true;
                    System.out.println("Codec ID: " + citanjeSaUlaza(1)[0]);


                    //Number of Data 1
                    numOD1 = (int) parseTeltonikaLong(citanjeSaUlaza(1));
                    System.out.println("Number of Data: " + numOD1);

                    for(int numAVL=0; numAVL<numOD1; numAVL++){
                        System.out.println("-------- " + (numAVL+1) + ". data ----------------");

                        //GPS ELEMENTS------------------------------------------------------
                        //TimeStamp
                        buffer = new byte[8];
                        buffer = citanjeSaUlaza(8);
                        long milis = parseTeltonikaLong(buffer);
                        //ispitati GTime ovdje ne u Uredjaju, kad vec imam uredjaj_fresh.
                        System.out.println("TimeStamp: " + parametri.DATUMVRIJEME.format(new Date(milis)));
                        uredjaj.setGtime(milis);
                        uredjaj.setGtimeTest(parametri.DATUMVRIJEME2.format(new Date(milis)));


                        //Priority
                        System.out.println("Priority: " + citanjeSaUlaza(1)[0]);

                        //Longitude X
                        buffer = new byte[4];
                        buffer = citanjeSaUlaza(4);
                        System.out.println("X: " + parseTeltonikaLong(buffer));
                        uredjaj.setX(parseTeltonikaLong(buffer)/10000000.0f);

                        //Latitude Y
                        buffer = new byte[4];
                        buffer = citanjeSaUlaza(4);
                        System.out.println("Y: " + parseTeltonikaLong(buffer));
                        uredjaj.setY(parseTeltonikaLong(buffer)/10000000.0f);

                        //Altitude
                        buffer = new byte[2];
                        buffer = citanjeSaUlaza(2);
                        System.out.println("Altitude: " + parseTeltonikaLong(buffer));
                        //isto ko i GTime
                        uredjaj.setAltitude((int) parseTeltonikaLong(buffer), uredjaj_fresh);

                        //Angle
                        buffer = new byte[2];
                        buffer = citanjeSaUlaza(2);
                        System.out.println("Angle: " + parseTeltonikaLong(buffer));
                        uredjaj.setDirection((int) parseTeltonikaLong(buffer));

                        //Sattelites
                        buffer = new byte[1];
                        buffer = citanjeSaUlaza(1);
                        System.out.println("Sattelites: " + parseTeltonikaLong(buffer));
                        uredjaj.setSatellites((short) parseTeltonikaLong(buffer));

                        //Speed
                        buffer = new byte[1];
                        buffer = citanjeSaUlaza(2);
                        System.out.println("Speed: " + parseTeltonikaLong(buffer));
                        //Ispitati brzinu ovjde a ne u Klasi Uredjaj
                        uredjaj.setSpeed(parseTeltonikaLong(buffer),uredjaj_fresh);
                        //END GPS ELEMENTS--------------------------------------------------

                        //------------------------------------------------------------------

                        //IO ELEMENTS-------(posebna funkcija)------------------------------
                        String logPoruke = "--->GPS vrijeme \"" + uredjaj.getGtime() + "\"<---\n";
                        
                        
                        //Event IO ID
                        buffer = new byte[1];
                        buffer = citanjeSaUlaza(1);
                        System.out.println("Event IO ID: " + parseTeltonikaLong(buffer));
                        logPoruke += "IO EventID= " + parseTeltonikaLong(buffer) + "\n";
                        IOEvent = (int) parseTeltonikaLong(buffer);

                        //Ukupan broj IO Elemenata
                        int numIO = (int) parseTeltonikaLong(citanjeSaUlaza(1));
                        System.out.println("Number of IO: " + numIO);
                        logPoruke += "Broj IO elemenata= " + numIO + "\n";

                        int j=1; //duzina IO elementa j*=2
                        for (int i=0; j<9;){
                            
                            
                            //Broj IO Elementa duzine 1B, 2B, 4B, 8B 
                            long numIOb = parseTeltonikaLong(citanjeSaUlaza(1));
                            System.out.println("Number of " + j + "B IO Elements: " + numIOb);
                            logPoruke += "Ukupno " + j + "B IO Elements: " + numIOb + "\n";

                            for(int k=0; k<numIOb; k++, i++){
                                long IOid = parseTeltonikaLong(citanjeSaUlaza(1));
                                long IOid_value = parseTeltonikaLong(citanjeSaUlaza(j));

                                System.out.println((k+1) + ". IO_ID: " + IOid + "\t IO_Value: " + IOid_value);
                                logPoruke += "  " + (k+1) + ". IO_ID: " + IOid + "\t IO_Value: " + IOid_value + "\n";
                                
                                //Punjenje uredjaja
                                ubaciUUredjajIOTeltonika(IOid, IOid_value);
                                
                                IOid =0; IOid_value =0;
                            }
                            if(i > numIO){
                                break;
                            }
                            j*=2; numIOb =0;
                        }
                        
                        
                        
                        //--------------------------------------------------------------
                        uredjaj_fresh = uredjaj;//Kopiraj podatke u uredjaj koji oznacavu proslu poziciju
                        uredjaji_IzBaze.get(redniBroj_Uredjaja_U_Listi).dodajVrijednostiPozicije(uredjaj);
                        uredjaj.setEvent((short) IOEvent);
                        uredjaj.setRedniBrojPozicije((short) ((numAVL & 0xFFFF)+1)); //unsigned short 0-65535
                        loger.ispisPoruka(logPoruke);
                        logPoruke = "";
                        
                        
                        provjera_pristiglog_gtime(uredjaj);
                        
                        //GeoCode
                        if(numAVL < 3){
                            uredjaj.setGeocode(parametri.dajGeoCodeOSM(uredjaj.getX(), uredjaj.getY(), uredjaj.getGtime(), uredjaj.getBrojUredjaja(), uredjaj));
                        }
                        
                        String ispisPozicije = "<POS N=" + uredjaj.getBrojUredjaja()+ " X=" + uredjaj.getX() + " Y=" + uredjaj.getY() + " H=" + uredjaj.getAltitude() + " S=" + uredjaj.getSpeed() + " D=" + uredjaj.getDirection() +
                                " IO=" + numIO + " A=" + uredjaj.getGtime(0) + " T=" + uredjaj.getGtime(1) + " E=" + uredjaj.getEvent() + " R=" + uredjaj.getRunMode() + " KM=" + uredjaj.getOdometer() + 
                                " SV=" + uredjaj.getSatellites() + " SF=0" + "> " + uredjaj.getGeocode() + " Poruka=" + (numAVL+1) + " IP:" + uredjaj.getIp() + ":" + uredjaj.getPort() + " ConnectionNumber=" + uredjaj.getConnectionNumber() + 
                                " Device<" + uredjaj.getBrojUredjaja() + ">";
                        loger.ispisPozicija(ispisPozicije);
                        sqlUpit.add(uredjaj.upis_FM_Teltonika());
                        uredjaj.resetVrijednostiPozicije();
                        //---------------------------------------------------------------
                        
                        
                        
                    //END IO ELEMENTS---------------------------------------------------
                        System.out.println("-------- End of " + (numAVL+1) + ". data ----------------");
                    }
                    
                    
                    //Number of Data 2
                    numOD2 = (int) parseTeltonikaLong(citanjeSaUlaza(1));
                    System.out.println("Number of Data: " + numOD2);
                    avlFlag = false;


                    //Racunanje CRC-16 sa polinomom 0xA001 i dobijanje njegove INT vrijednosti
                    byte[] avlCRC = new byte[teltonica_AVLdata_for_CRC16.size()];
                    for (int i =0; i < teltonica_AVLdata_for_CRC16.size(); i++) //konvertovanje ArrayList u Array
                        avlCRC[i] = teltonica_AVLdata_for_CRC16.get(i); 

                    //reset AVLdata
                    teltonica_AVLdata_for_CRC16.clear();
                    teltonica_AVLdata_for_CRC16 = new ArrayList<>();

                    int crcIzracunat = getCrc(avlCRC);

                    //Dobijanje CRC-16 vrijednosti od uredjaja
                    
                    buffer = new byte[4];
                    buffer = citanjeSaUlaza(4);
                    long crcDobijenOdUredjaja = parseTeltonikaLong(buffer); //crc-16 kao niz od 4 bajta
                    System.out.println("CRC-16: " + crcDobijenOdUredjaja);

                    

                    //provejra da li su CRC-16 vrijednosti jednake
                    if (crcDobijenOdUredjaja == crcIzracunat){
                        System.out.println("CRC-16 values MATCH!!! [Uredajaj= " + uredjaj.getBrojUredjaja() + "] Primljeni podaci se upisuju u tabelu");
                        for (int i = 0; i<sqlUpit.size(); i++) {
                            parametri.izvrsiUpit(sqlUpit.get(i),"CALL");
                        }
                        
                        pp_pozicije.clear(); //samo ako je arrayList; Inace se mora ici **for(String gt : pp_pozicije){gt = null;}**
                        
                        sqlUpit.clear();
                        //povratna informacija uredjaju koliko je primljeno AVL podataka
                        dos.writeInt(numOD2);
                    }else{
                        System.out.println("CRC-16 values MISSMATCH!!! [Uredajaj= " + uredjaj.getBrojUredjaja() + "] Primljeni podaci se odbacuju");
                        loger.ispisGreska("CRC-16 values MISSMATCH!!!  [Uredajaj= " + uredjaj.getBrojUredjaja() + "] Primljeni podaci se odbacuju");
                    }
                    
                    //ispis raw data
                    loger.ispisPoruka("RawData[Uredajaj= " + uredjaj.getBrojUredjaja() + "]: " + raw + "\n");
                    loger.ispisPoruka("----------------------------------------------------------------");
                    System.out.println(raw);
                    System.out.println("----------------------------------------------------------------");
                    raw = "";
                }//end of while(buufer4 != -1)- cita novi AVL zapis
                
                System.out.println("----------------Izlaz iz thread-a [Uredajaj= " + uredjaj.getBrojUredjaja() + "] - " + parametri.DATUMVRIJEME.format(new Date()));
            }catch(IOException e){
                System.out.println("Greska, TeltonicamMsg.ReceiveTeltonicaData()[Uredajaj= " + uredjaj.getBrojUredjaja() + "]: \n\t" + e.toString());
                loger.ispisGreska("Greska, TeltonicamMsg.ReceiveTeltonicaData()[Uredajaj= " + uredjaj.getBrojUredjaja() + "]: \n\t" + e.toString());
            }
        }
        
        //END of prijem podataka Teltonica--------------------------------------
        //----------------------------------------------------------------------
        
        
        //----------------------------------------------------------------------
        //Prijem podataka Queclink---------------------------------------
        
        /**
         * Prijem AVL podataka sa QuecLink GL300 input stream-a
         */
        private void odobravanjeKonekcije_GL300N(String poruka){
            String countNumber = "";
            String protocolVersion = "";
            String vratiSACK ="";
            
            //strelica za online -->
           //+ACK:GTHBD,02010D,135790246811220,30049-GL300N,20100214093254,11F0$  
            
           
           
            String acknowledgementMsg = poruka;
            
            try{
                
                //uredjaj_fresh = parametri.pozicijaIzFresh(uredjaj.getBrojUredjaja()); //nullpointer exception????
                
                
                if (acknowledgementMsg == null){
                    System.out.println("Greska, poruka od uredjaja(" + uredjaj.getBrojUredjaja() + "-" + uredjaj.getTipUredjaja()+ ") je null");
                    loger.ispisGreska("Greska, poruka od uredjaja(" + uredjaj.getBrojUredjaja() + "-" + uredjaj.getTipUredjaja()+ ") je null");
                    return;
                }

                String[] porAck = acknowledgementMsg.split(",");
                if(porAck == null){
                    System.out.println("Greska, poruka od uredjaja(" + uredjaj.getBrojUredjaja() + "-" + uredjaj.getTipUredjaja()+ ") je null");
                    loger.ispisGreska("Greska, poruka od uredjaja(" + uredjaj.getBrojUredjaja() + "-" + uredjaj.getTipUredjaja()+ ") je null");
                    return;
                }

                if (porAck[0].contains("GTHBD")){ //Heartbeat
                    try{
                        protocolVersion = porAck[1];
                        countNumber = porAck[5];

                        vratiSACK = "+SACK:GTHBD," + protocolVersion + "," + countNumber + "$";
                        
                        //loger.ispisPoruka("RawData ["+ uredjaj.getBrojUredjaja() + "-" + uredjaj.getTipUredjaja() +"]=" + raw);
                        raw = "";
                        
                        dos.writeUTF(vratiSACK);
                        dos.flush();
                        uredjaj.setConnectionNumber(clientCount - 1);
                        
                    }
                    catch (IOException e){
                        System.out.println("Greska, prilikom slanja +SACK:GTHBD " + parametri.DATUMVRIJEME.format(new Date()) + "\n" + e.toString());
                        loger.ispisGreska("Greska, prilikom slanja +SACK:GTHBD \n\tException: " + e.toString());
                    }

                    String freshSatDB = "UPDATE gps_fresh SET gps_fresh.Ctime=now() WHERE gps_fresh.Uredjaj=" + uredjaj.getBrojUredjaja();//ctime i update ctime
                    parametri.izvrsiUpit(freshSatDB, "UPDATE");
                    
                    long HBTime = parametri.DATUM_GL300N.parse(porAck[4]).getTime(); //HeartBeat time
                    
                    if(uredjaj.getStatusRuteX11() != 0){
                        long gtimeMilis = parametri.DATUMVRIJEME.parse(uredjaj_fresh.getGtime()).getTime();
                        if((HBTime - gtimeMilis) > parametri.minuta10){
                            uredjaj.setStatusRuteX11((short) 0);
                            loger.ispisPoruka("GL200/GT300N/GT500, zatvorena ruta");
                            String pozivProcedure = "{CALL java2db_GL(" + uredjaj.getBrojUredjaja() + ", 0, 0, '" + uredjaj.getGtime() + "', 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'poz', " + uredjaj.getIDVozaca() + ", 0, 0, " + ((uredjaj.getRedniBrojPozicije())) + ", 0, " + uredjaj.getSpeedMax() + ", " + uredjaj.getFk_ID_moje_lokacije() + ")}";
                            parametri.izvrsiUpit(pozivProcedure, "CALL");
                        }
                    }


                }else if (porAck[0].contains("+ACK:")){
                    System.out.println(parametri.DATUMVRIJEME.format(new Date()) + "Poruka [Uredjaj= " + uredjaj.getBrojUredjaja() + "]  " + acknowledgementMsg + " " + parametri.DATUMVRIJEME.format(new Date()) + "\n");
                    loger.ispisPoruka("Poruka [Uredjaj= " + uredjaj.getBrojUredjaja() + "]  " + acknowledgementMsg + " " + parametri.DATUMVRIJEME.format(new Date()) + "\n");
                    raw = "";
                }else{
                    //promjeniti poruku greske
                    System.out.println(parametri.DATUMVRIJEME.format(new Date()) + "Greska, ServerKlasa.odobravanjeKonekcije_GL300N(boolean bool)[Uredajaj= " + uredjaj.getBrojUredjaja() + "] poruka ne sadrzi ni \"+ACK:GTHBD\" ni \"+ACK:\"\n");
                    loger.ispisGreska("Greska, ServerKlasa.odobravanjeKonekcije_GL300N(boolean bool)[Uredajaj= " + uredjaj.getBrojUredjaja() + "] poruka ne sadrzi ni \"+ACK:GTHBD\" ni \"+ACK:\"\n");
                    raw = "";
                }
            }//-------Zatvaranje velikog try{}
            catch (Exception e){
                System.out.println(parametri.DATUMVRIJEME.format(new Date()) + "Greska, ServerKlasa.odobravanjeKonekcije_GL300N(boolean bool)[Uredajaj= " + uredjaj.getBrojUredjaja() + "]" + "\t" + e.toString());
                loger.ispisGreska("Greska, ServerKlasa.odobravanjeKonekcije_GL300N[Uredajaj= " + uredjaj.getBrojUredjaja() + "]" + "\t" + e.toString());
                raw = "";
            }
            
            
        }
        
        /**
         * Funkcija za citanje AVL podataka od uredjaja
         */
        private void readAVL_GL300N(String poruka){
            float fX = 0f;   //longitde //x
            float fY = 0f;   //latitude //y
            String brojPoslanihPoruka = "";
            
            
                        
            try{
                String[] porukaDijelovi = poruka.split(",");

                String tipPoruke = porukaDijelovi[0];

                uredjaj.setEvent(tipPoruke);
                
                
                if(tipPoruke.contains("GTPNA") || tipPoruke.contains("GTPFA")){
                    //-----Event report bez LastPosition-------------------
                    //Uredjaj upaljen (GTPNA) ili ugasen (GTPFA)
                    
                    uredjaj.dodajVrijednostiPozicije(uredjaj_fresh); //posljednja pozicija iz fresh-a
                    Date sendTime = parametri.DATUM_GL300N.parse(porukaDijelovi[4]);
                    uredjaj.setGtime(parametri.DATUMVRIJEME.format(sendTime)); //send time kao Gtime
                    
                    //-----End of Event Report bez LastPosition------------
                }

                if(tipPoruke.contains("GTEPN") || tipPoruke.contains("GTEPF") || tipPoruke.contains("GTBTC") || tipPoruke.contains("GTSTC") ||
                        tipPoruke.contains("GTBPL")){
                    //-----Event Report sa LastPosition--------------------
                    //Eksterno napajanje prikopcano(GTEPN)/iskopcano(GTEPF); Punjenje pocelo(GTBTC)/zaustavljeno(GTSTC); Slab nivo baterije(GTBPL)
                    //posljednja poznata lokacija, tj. posljednje poslate x i y koordinate

                    uredjaj.dodajVrijednostiPozicije(uredjaj_fresh);
                    
                    //za GTBPL uraditi i setBatteryLevel
                    
                    //-----End of Event Report sa LastPosition-------------
                }

                if(tipPoruke.contains("GTFRI") || tipPoruke.contains("GTGEO") || tipPoruke.contains("GTSPD") || tipPoruke.contains("GTSOS") ||
                        tipPoruke.contains("GTPNL") || tipPoruke.contains("GTPFL") || tipPoruke.contains("GTNMR")){
                    //-----Position Related Report-------------------------------
                    
                    brojPoslanihPoruka = porukaDijelovi[6];
                    
                    int gpsAccuracy = Integer.parseInt(porukaDijelovi[7]);
                    uredjaj.setAccuracy(gpsAccuracy);
                    
                    String speed = porukaDijelovi[8];
                    
                    String direction = porukaDijelovi[9];
                    String altitude = porukaDijelovi[10];

                    fX = Float.valueOf(porukaDijelovi[11]);
                    fY = Float.valueOf(porukaDijelovi[12]);

                    String gTime = porukaDijelovi[13];

                    String odoMileage = porukaDijelovi[18];

                    

                    uredjaj.setX(fX);
                    uredjaj.setY(fY);

                    if (uredjaj.getEvent() == 0) {
                        //uredjaj.setSpeed(0); // na db za x11 -0/1 speed=0
                    }
                    

                    if (direction.equals("") || direction.equals(" ")){
                        uredjaj.setDirection(0);
                    }else{
                        uredjaj.setDirection(Integer.parseInt(direction));
                    }
                    
                    if (speed.equals("") || speed.equals(" ")){
                        uredjaj.setSpeed(0f);
                    }else{
                        uredjaj.setSpeed(Float.parseFloat(speed));
                    }

                    if (altitude.equals("") || altitude.equals(" ")){
                        uredjaj.setAltitude(0);
                    }else{
                        uredjaj.setAltitude((int) Float.parseFloat(altitude));
                    }

                    uredjaj.setBatteryLevel(Integer.parseInt(porukaDijelovi[19])); //status baterije u %


                    if(gTime.length() < 5){
                        //uredjaj.setGtime(new Date().getTime());
                        loger.ispisPoruka("Greska, Uredjaj= " + uredjaj.getBrojUredjaja() + " nema GPS Fix. GTime= " + uredjaj.getGtime());
                        loger.ispisGreska("Greska, Uredjaj= " + uredjaj.getBrojUredjaja() + " nema GPS Fix. GTime= " + uredjaj.getGtime());
                    }else if (gTime.length() == 14){
                        uredjaj.setGtime(parametri.DATUM_GL300N.parse(gTime).getTime());
                    }
                    
                    long GtimeFresh = parametri.DATUMVRIJEME.parse(uredjaj_fresh.getGtime()).getTime();
                    long GtimeTren = parametri.DATUM_GL300N.parse(gTime).getTime();
                    
                    if(tipPoruke.contains("GTNMR")){
                        int kretanje_mirovanje = Integer.parseInt(porukaDijelovi[5],16);
                        long razlikaGtime = GtimeTren - GtimeFresh;
                        if(kretanje_mirovanje == 0 && razlikaGtime > parametri.minuta10){
                                uredjaj.setEvent(11);
                                uredjaj.setRunMode((short) 0);
                                uredjaj.setStatusRuteX11((short) 0);
                        }
                        else if (kretanje_mirovanje == 1 && razlikaGtime < parametri.sekundi30){
                                uredjaj.setEvent(11);
                                uredjaj.setRunMode((short) 1);
                                uredjaj.setStatusRuteX11((short) 1);
                        }
                        
                    }

                    if(odoMileage.equals("") || odoMileage.equals(" ")){
                        uredjaj.setMileage(0);
                        loger.ispisGreska("Greska Uredjaj = " + uredjaj.getBrojUredjaja() +", readAVL_GL300N(poruka): Odometar je praznina (" + odoMileage + ") u poruci za uredjaj= ");
                    }
                    else if(Double.parseDouble(odoMileage) < uredjaj_fresh.getMileage()){
                        double razlikaMileage = Double.parseDouble(odoMileage) - uredjaj_fresh.getMileage();
                        loger.ispisGreska("Greska Uredjaj = " + uredjaj.getBrojUredjaja() +", readAVL_GL300N(poruka): Mileage<" + odoMileage + "> je manja od vrijednosti iz fresh-a <" + uredjaj_fresh.getMileage() + "> za razliku = " + razlikaMileage);
                        uredjaj.setMileage(uredjaj_fresh.getMileage());
                    }
                    else {
                        if(uredjaj.getEvent() == 2 || uredjaj.getEvent() == 11){
                            uredjaj.setMileage(Double.parseDouble(odoMileage));
                        }
                        else{
                            uredjaj.setMileage(uredjaj_fresh.getMileage());
                        }
                    }
                    //-----Enf of Position Related Report----------------------------
                    if (tipPoruke.contains("ESP:")){//+R je vec procitano tako da je ostalo samo ESP:
                        gcFlag = true;
                    }
                    
                    if(gcFlag){
                        //---------Upit za geoCode---------
                        if(uredjaj.getGCTip() == 0){//Cyber
                            uredjaj.setGeocode("");
                        }else if(uredjaj.getGCTip() == 1){ //OSM
                            uredjaj.setGeocode(parametri.dajGeoCodeOSM(fX, fY, uredjaj.getGtime(), uredjaj.getBrojUredjaja(), uredjaj_fresh));
                        }else if(uredjaj.getGCTip() == 2){//Cyber + osm
                            uredjaj.setGeocode("");
                        }else if(uredjaj.getGCTip() == 3){//bez geo koda
                            uredjaj.setGeocode("");
                        }else if(uredjaj.getGCTip() == 4){ //geo kod preko POI, poste RS
                            uredjaj.setGeocode(parametri.dajGeoCodeOSM(fX, fY, uredjaj.getGtime(), uredjaj.getBrojUredjaja(), uredjaj_fresh));
                        }
                        //---------------------------------
                    }
                    
                    if(tipPoruke.contains("UFF:")){//+B je vec procitano tako da je ostalo samo UFF:// ovdje provjera dali je +BUFF kako bi se jednom izvrsila provjera geoCode
                        uredjaj.setGeocode(uredjaj.getGeocode());//prepisace novu vrikednost
                        gcFlag = false;
                    }

                }
                
                uredjaj_fresh = uredjaj;
                //loger.ispisPoruka(uredjaj.upis_GL300N());//test ispis poruke
                parametri.izvrsiUpit(uredjaj.upis_GL300N(), "CALL");
                String ispisPozicije = "<POS N=" + uredjaj.getBrojUredjaja()+ " X=" + uredjaj.getX() + " Y=" + uredjaj.getY() + " H=" + uredjaj.getAltitude() + " S=" + uredjaj.getSpeed() + " D=" + uredjaj.getDirection() +
                                    " IO=" + uredjaj.getRunMode() + " A=" + uredjaj.getGtime(0) + " T=" + uredjaj.getGtime(1) + " E=" + uredjaj.getEvent() + " R=" + uredjaj.getRunMode() + " KM=" + uredjaj.getMileage() + 
                                    " GPSAccuracy= " + uredjaj.getAccuracy() + ">" + uredjaj.getGeocode() + " IP:" + uredjaj.getIp() + ":" + uredjaj.getPort() + " ConnectionNumber=" + uredjaj.getConnectionNumber();
                loger.ispisPozicija(ispisPozicije);
                
                //loger.ispisPoruka("RawData ["+ uredjaj.getBrojUredjaja() + "-" + uredjaj.getTipUredjaja() +"]=" + raw);
                raw = "";
                
            }
            catch(Exception e){
                //dodati kasnije
                System.out.println("Greska, ServerKlasa.readAVL_GL300N(poruka)[" + uredjaj.getBrojUredjaja() + "] za poruku " + poruka + "\t" + e.toString());
                loger.ispisGreska("Greska, ServerKlasa.readAVL_GL300N(poruka)[" + uredjaj.getBrojUredjaja() + "] za poruku " + poruka + "\t" + e.toString());
            }

            
            
        }
        //END of prijem podataka Queclink---------------------------------------
        //----------------------------------------------------------------------
        
        
        /**
         * Funkcija koja dodijeljuje vrijednosti klase Pozicija na osnovu ID IO elemenata
         * 
         * @param ID IO Elementa
         * @param IOVrijednost Vrijednost IO Elementa
         * @param uredjaj je uredjaj u koji se upisuju vrijednosti
         */
        private void ubaciUUredjajIOTeltonika(long ID, long IOVrijednost){
            //DIN1 ili Ignition
            if(ID == 1 || ID == 239){ 
                uredjaj.setRunMode((short) IOVrijednost);
            }
            //ExternalVoltage u [mV] milivoltima;
            else if (ID == 66){
                uredjaj.setPowerSupply(IOVrijednost);
            }
            //Speed
            else if (ID == 24){
                uredjaj.setSpeed(IOVrijednost, uredjaj_fresh);
            }
            //Battery voltage [mV] 
            else if (ID == 67){
                uredjaj.setBatteryLevel(IOVrijednost);
            }
            //Trip Odometar 
            else if (ID == 199){
                uredjaj.setOdometer(IOVrijednost);
            }
            //Analoig Input 1
            else if(ID == 9){
                uredjaj.setAnalog1(IOVrijednost, uredjaj_fresh);
            }
            //GSM Signal Level
            else if(ID == 21){
                uredjaj.setGsmSignalLevel((short) IOVrijednost);
            }
        }
                        
        /**
         * Dodavanje vodece nule kako bi se ispisala pravinlo vrijednost
         * @param str String kojem se dodaje vodeca nula ako mu je duzina neparna
         *            inace se samo vraca string
         * @return String sa vodecom nulom
         */
        private String leadingZero(String str){
            if((str.length()%2) == 1){
                return "0" + str;            
            }else{
                return str;
            } 
        }
        
        /**
         * Funkcija koja vraca <code>int</code> vrijednost CRC-16 koji se dobije
         * iz niza bajtova pokupljenih sa stream-a
         * 
         * 
         * @param buffer niz primljenih bajtova duzine DataField
         * @return int vrijednost nizaq bajtova izrazena kao int vrijednost
         */
        public int getCrc(byte[] buffer) {
            return getCrc16(buffer, 0, buffer.length, 40961, 0);
        }
        
        
        /**
         * Funkcija koja obavlja racunanje CRC-16 sa polinomom 0xA001
         * 
         * @param buffer Proslijedeni byte niz,
         * @param offset Vrijednost koja mu se proslijedi i koja kaze za koliko 
         *                  da se pomjeri od pocetka niza kako bi poceo sa racunanjem,
         * @param bufLen vrijednost duzine buffer niza,
         * @param polynom int vrijednost polinoma koj ise koristi pri racunjanju,
         * @param preset
         * 
         * @return int Vrijednost  crc-a za proslijedjene batove;
         */
        public int getCrc16(byte[] buffer, int offset, int bufLen, int polynom, int preset) {
            preset &= 0xFFFF;
            polynom &= 0xFFFF;

            int crc = preset;
            for (int i = 0; i < bufLen; i++) {
              int data = buffer[((i + offset) % buffer.length)] & 0xFF;
              crc ^= data;
              for (int j = 0; j < 8; j++) {
                if ((crc & 0x1) != 0) {
                  crc = crc >> 1 ^ polynom;
                } else {
                  crc >>= 1;
                }
              }
            }

            return crc & 0xFFFF;
        }
    }
}
