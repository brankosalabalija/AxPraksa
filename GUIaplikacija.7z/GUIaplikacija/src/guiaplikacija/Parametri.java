/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guiaplikacija;

import java.io.File;
import java.io.FileNotFoundException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author branko.salabalija
 */
public final class Parametri{
    private static Logeri loger = null;
    /**
     * Broj servera na kjojem je pokrenuta java
     */
    private String appserver = null;
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    
    //za pristup SatDB (user, pass i ip od baze se citaju iz fajla)
    private String url_satdb = "jdbc:mysql://";  
    private String user_satdb = null;
    private String password_satdb = null;
    
    //za pristup GIS (hardcoded)
    private String url_gis = "jdbc:postgresql://";
    private String ip_gisdb = "10.253.253.11/gis";  //null;//
    private String user_gis = "satwork";            //null;//
    private String password_gis = "saTW0rk";        //null;//
    
    
    private Connection konSatDB = null;
    private Connection konGIS = null;
    
    /**
     * 30 sekundi u miliskenudama
     */
    public long sekundi30 = 30000;
    /**
     * 1 sat u milisekundama
     */
    public long sati1  = 360000;
    /**
     * 20 minuta u milisekundama
     */
    public long minuta20 = 120000; //20 minuta za gTime
    /**
     * 10 minuta u milisekundama
     */
    public long minuta10 = 60000; //10 minuta
    public static final int PORT = 25000;
    /**
     * Format datuma yyyy-MM-dd
     */
    public SimpleDateFormat DATUM = new SimpleDateFormat("yyyy-MM-dd");
    /**
     * Format datuma yyMMddHHmm
     */
    public SimpleDateFormat DATUM_fajl_log = new SimpleDateFormat("yyMMddHHmm");
    /**
     * Format datuma yyMM
     */
    public SimpleDateFormat DATUM_folder_log = new SimpleDateFormat("yyMM");
    /**
     * Format datuma yyyy-MM-dd HH:mm:ss
     */
    public SimpleDateFormat DATUMVRIJEME = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    public SimpleDateFormat DATUMVRIJEME2 = new SimpleDateFormat("yyyy-MM-dd HH:mm");
    /**
     * Format datuma iz GL300N poruka  yyyyMMddHHmmss
     */
    public SimpleDateFormat DATUM_GL300N = new SimpleDateFormat("yyyyMMddHHmmss");
    /**
     * Format vremena HH:mm:ss
     */
    public SimpleDateFormat VRIJEME = new SimpleDateFormat("HH:mm:ss");
    

    /**
     * Objekat sa {@code null} vrijednostima
     */
    public Parametri() {
        this.loger = GUIsatwork.getInstance();
    }
    
    /**
     * Citanje .conf fajla
     * @param imeFajla ime fajla iz kojeg se cijatu podaci
     * @param lg
     */
    public Parametri(String imeFajla, Logeri lg) {
        this.loger = lg;
        String line = "";
        try {
            Scanner scn = new Scanner( new File("./" + imeFajla));
            
            while(scn.hasNextLine()){
                line = scn.nextLine();
                String[] parts = line.split("=");
                switch (parts[0]){
                    case "ID_app_server": {this.appserver = parts[1].replace(";", "");}
                    break;
                    case "DB_ip": {this.url_satdb += parts[1].replace(";", "");}
                    break;
                    case "DB_user": {this.user_satdb = parts[1].replace(";", "");}
                    break;
                    case "DB_pass": {this.password_satdb = parts[1].replace(";", "");}
                    break;
                    case "DB_name": {this.url_satdb += "/" + parts[1].replace(";", "");}
                    break;
                    default:                    
                }
                line ="";
            }
//            this.url_satdb += "?useTimezone=true&serverTimezone=UTC";//za jdbc konektor v8.0.15
        } catch (FileNotFoundException ex) {
            System.out.println("Fajl nije pronadjen\t" + ex.toString());
            loger.ispisGreska("Fajl nije pronadjen\t" + ex.toString());
        }
        
        konekcijaSatDBBaza();
        konekcijaGISServer();
    }
    
    /**
     * Funkcija koja zatvara konekciju sa SatDB
    */
    public void zatvoriKonekcijuSatDB(){
        try {
            if (konSatDB != null)
                    konSatDB.close();
            else{
                System.out.println("Konekcija sa bazom je vec zatvorena ili nije nikad ni otvorena");
                loger.ispisGreska("Konekcija sa bazom je vec zatvorena ili nije nikad ni otvorena");
                
            }
        } catch (SQLException ex) {
            System.out.println("Greska, Parametri.zatvoriKonekciju() - Greska prilikom zatvaranja konekcije\t" + ex.toString());
            loger.ispisGreska("Greska, Parametri.zatvoriKonekciju() - Greska prilikom zatvaranja konekcije\t" + ex.toString());
            
        }
    }
    
    /**
     * Funkcija koja zatvara konekciju sa GIS
    */
    public void zatvoriKonekcijuGIS(){
        try {
            if (konGIS != null)
                    konGIS.close();
            else{
                System.out.println("Konekcija sa bazom je vec zatvorena ili nije nikad ni otvorena");
                loger.ispisGreska("Konekcija sa bazom je vec zatvorena ili nije nikad ni otvorena");
            }
        } catch (SQLException ex) {
            System.out.println("Greska, Parametri.zatvoriKonekciju() - Greska prilikom zatvaranja konekcije\t" + ex.toString());
            loger.ispisGreska("Greska, Parametri.zatvoriKonekciju() - Greska prilikom zatvaranja konekcije\t" + ex.toString());
        }
    }
    
    /**
     * Funkcija koja izvrsava SQL upite nad bazom i vraca rezultat upita kao
     * String 
     * 
     * @param upit upti koji se izvrsava nad bazom
     * @param tip tip upita, tj. da li je upit SELECT, INSERT, CALL, CREATE, 
     * @return U zavisnosti od tipa upita funkcija vraca {@code String} koji sadrzi:
     *          <ul>
     *          <li>kompletan red ako je tip SELECT (<strong> U testnoj fazi, nije za upotrebu!!!</strong>)</li>
     *          <li>broj redova koji modifikovan ako je UPDATE, INSERT</li>
     *          <li>prazan string ako je tip CALL</li>
     *          </ul>
     */
    public synchronized String izvrsiUpit(String upit, String tip){
        Statement poruka = null;
        String rezultat = "";
        boolean sqlFlag = true;
        
        while(sqlFlag){
            try {
                if (!konSatDB.isValid(30)){//cekaj do 30 sekundi na odgovor od baze da je spremna za upis
                    loger.ispisGreska("->Obnavljanje konekcije sa SatDB<-");
                    sqlFlag = true;//drzi flag na true
                    konekcijaSatDBBaza();//obnovi konekciju
                }
                else{
                    poruka = konSatDB.createStatement();
                    switch(tip){
                        case "SELECT": {
                            ResultSet rs = poruka.executeQuery(upit);
                            ResultSetMetaData rsmd = rs.getMetaData();
                            int brojKolona = rsmd.getColumnCount();
                            
                            while (rs.next()){
                                for(int i=1; i<=brojKolona; i++){
                                    rezultat += rsmd.getColumnLabel(i) + ":" + rs.getString(i) + "\t";
                                }
                                rezultat += "\n";
                            }
                            rs.close();
                            sqlFlag = false; 
                        }
                        break;
                        case "INSERT":{
                            rezultat = "" + poruka.executeUpdate(upit);
                            sqlFlag = false;
                        }
                        break;
                        case "UPDATE":{
                            rezultat = "" + poruka.executeUpdate(upit);
                            sqlFlag = false;
                        }
                        break;
                        case "CALL":{
                            poruka.execute(upit);
                            sqlFlag = false;
                        }
                        break;//izlaz iz switch-a
                    }
                }
            break;//izlaz iz while petlje
            } catch (Exception ex) {
                System.out.println("Greska u Parametri.izvrsiUpit\t" + ex.toString());
                loger.ispisGreska("Greska u Parametri.izvrsiUpit\t" + ex.toString());
                sqlFlag = false;
            }
        }
        return rezultat;
    }
    
    /**
     * Funkcija koja vraca GeoCode kao {@code String} na osnovu primljenih
     * {@code x} i {@code y} vrijednosti koordinata
     * @param x X-koordinata tipa {@code float} (longitude)
     * @param y Y-koordinata tipa {@code float} (latitude)
     * @param gtime Gtime od trenutne pozicije
     * @param brojUredjaja izdvojen broj uredjaja za koji se trazi GeoCode
     * @param ured uredjaj za koji se trazi GeoCode
     * @return {@code String} rezultat od GIS-a na osnovu X i Y koordinata
     */
    public synchronized String dajGeoCodeOSM(float x, float y, String gtime, int brojUredjaja, Uredjaj ured){
        Float fX = x;
        Float fY = y;
        boolean isInfinite = false, psqlFlag = true;
        String geoCode = "N/A";
        CallableStatement callStmt = null;
        
        try{
            if (fX.isInfinite()){
                isInfinite = true;
                loger.ispisGreska("Greska, ServerKlasa.geoCodeOSM(float x, float y, String gtime, int brojUredjaja, Uredjaj ured) <" + brojUredjaja +"> Float isInfinite fX= " + x + " Gtime = " + gtime);
            }
            if (fY.isInfinite()){
                isInfinite = true;
                loger.ispisGreska("Greska, ServerKlasa.geoCodeOSM(float x, float y, String gtime, int brojUredjaja, Uredjaj ured) <" + brojUredjaja +"> Float isInfinite fY= " + y + " Gtime = " + gtime);
            }

            if(!isInfinite){
                String geoCodePoziv = "{? = call dajgeokod_new(" + x + "," + y + ")}";

                try{
                    if (konGIS.isValid(30)){//cekaj do 30 sekundi na odgovor od baze da je spremna za upis //potrebno obnoviti konekciju negdje
                        callStmt = konGIS.prepareCall(geoCodePoziv);
                        callStmt.registerOutParameter(1, java.sql.Types.VARCHAR);
                        callStmt.execute();
                        callStmt.setQueryTimeout(3);
                        geoCode = callStmt.getString(1);
                        callStmt.close();
                    }else{
                        konekcijaGISServer();
                        loger.ispisGreska("Nema konekcije sa GIS. Preskace se geolokacija i obnavlja se konekcija");
                    }
                }
                catch(SQLException se){
                    System.out.println("Greska pri dobijanju Geo Koda; Parametri.dajGeoCodeOSM(float x, float y, int brojUredjaja) <" + brojUredjaja + ">\t" + se.toString());
                    loger.ispisGreska("Greska pri dobijanju Geo Koda; Parametri.dajGeoCodeOSM(float x, float y, int brojUredjaja) <" + brojUredjaja + ">\t" + se.toString());
                }
            }
        }
        catch(Exception e){
            System.out.println("Greska, Parametri.dajGeoCodeOSM(float x, float y, int brojUredjaja) <" + brojUredjaja + ">\t" + e.toString());
            loger.ispisGreska("Greska, Parametri.dajGeoCodeOSM(float x, float y, int brojUredjaja) <" + brojUredjaja + ">\t" + e.toString());
            
        }
        return geoCode;
        
    }
    
    /**
     * Funkcija koja vraca listu uredjaja iz baze vezane za odredjeni server
     * @return Lista objekata tipa Uredjaj
     */
    public List<Uredjaj> listaUredjaja(){
        List<Uredjaj> uredjajiIzBaze = new ArrayList<>();
        Statement selectUredjaj = null;
        ResultSet rs = null;
        
        try{
            
            selectUredjaj = konSatDB.createStatement();
            
            String query = "SELECT gps_uredjaj.Uredjaj, gps_fresh.Gtime, sim_kartica.BrojKartice, users.Naziv, gps_uredjaj.IMEI, gps_uredjaj.GCTip, vozilo.RegBr, gps_uredjaj.DatumUgradnje, vozilo.ID_vozilo, gps_uredjaj.VrijemeSlanja, gps_uredjaj.VrijemeSlanjaEngineOff, gps_uredjaj_tip.TipUredjaja, gps_uredjaj.UredjajPass, gps_uredjaj.Firmware, gps_uredjaj.PDA, gps_uredjaj.SleepMode, vozac.IdentHex, vozac.ID_vozac, gps_uredjaj.UgaoSlanja, gps_uredjaj.DistancaSlanja, sim_kartica_provider.Naziv " +
                                "FROM gps_uredjaj " +
                                "LEFT JOIN sim_kartica ON gps_uredjaj.fk_ID_sim_kartica = sim_kartica.ID_sim_kartica " +
                                "LEFT JOIN sim_kartica_provider ON sim_kartica.fk_ID_sim_kartica_provider = sim_kartica_provider.ID_sim_kartica_provider " +
                                "LEFT JOIN app_server ON gps_uredjaj.fk_ID_app_server = app_server.ID_app_server " +
                                "LEFT JOIN gps_uredjaj_tip ON gps_uredjaj.fk_ID_gps_uredjaj_tip = gps_uredjaj_tip.ID_gps_uredjaj_tip " +
                                "LEFT JOIN grupa ON gps_uredjaj.fk_ID_grupa_default = grupa.ID_grupa " +
                                "LEFT JOIN users ON grupa.fk_ID_users = users.ID_users " +
                                "LEFT JOIN vozilo ON gps_uredjaj.fk_ID_vozilo = vozilo.ID_vozilo " +
                                "LEFT JOIN gps_fresh ON gps_uredjaj.Uredjaj = gps_fresh.Uredjaj " +
                                "LEFT JOIN vozac ON vozilo.ID_vozilo = vozac.fk_ID_vozilo " +
                                "WHERE gps_uredjaj.DatumUgradnje is not null " +
                                "AND gps_uredjaj.fk_ID_app_server = " + appserver;
            
            
            rs = selectUredjaj.executeQuery(query);
            while (rs.next()){
                Uredjaj uredjaj = new Uredjaj(
                                    rs.getInt("Uredjaj"),
                                    rs.getLong("IMEI"),
                                    rs.getString("Gtime"),
                                    rs.getString("BrojKartice"),
                                    rs.getString("Naziv"),
                                    rs.getShort("GCTip"),
                                    rs.getString("RegBr"),
                                    rs.getString("DatumUgradnje"),
                                    rs.getInt("ID_vozilo"),
                                    rs.getInt("VrijemeSlanja"),
                                    rs.getInt("VrijemeSlanjaEngineOff"),
                                    rs.getString("TipUredjaja"),
                                    rs.getString("UredjajPass"),
                                    rs.getString("Firmware"),
                                    rs.getShort("PDA"),
                                    rs.getShort("SleepMode"),
                                    rs.getString("IdentHex"),
                                    rs.getShort("ID_vozac"),
                                    rs.getInt("UgaoSlanja"),
                                    rs.getInt("DistancaSlanja"),
                                    rs.getString("Naziv"),
                                    loger,
                                    this
                                    );
                uredjajiIzBaze.add(uredjaj);
            }
        }catch(SQLException sqle){
            System.out.println("Greska u Parametri.listaUredjaja\t" + sqle.toString());
            loger.ispisGreska("Greska u Parametri.listaUredjaja\t" + sqle.toString());
        }finally{
            if(rs != null) {
                try {
                    rs.close();
                } catch (SQLException ex) {
                    System.out.println("Greska prilikom zatvaranja ResultSet-a u Parametri.listaUredjaja\t" + ex.toString());
                    loger.ispisGreska("Greska prilikom zatvaranja ResultSet-a u Parametri.listaUredjaja\t" + ex.toString());
                }
            }
        }
        
        
        return uredjajiIzBaze;
    }    
    
    public synchronized Uredjaj pozicijaIzFresh(int brojUredjaja){
        Uredjaj ur = new Uredjaj();
        Statement selectFreshUredjaj = null;
        ResultSet rs = null;
        boolean psqlFlag = true;
        
        //ne izvrsi se kako treba. vrati se prazan uredjaj. (uredjaj sa pocetnim vrijednostima)
        //zamjeniti sa novim konstruktorom za fresh uredjaje
        
        try{
            while (psqlFlag){
                if (!konSatDB.isValid(30)){//cekaj do 30 sekundi na odgovor od baze da je spremna za upis
                    psqlFlag = true;
                    loger.ispisGreska("->Obnavljanje konekcije sa SatDB<-");
                    konekcijaSatDBBaza();//obnovi konekciju
                }
                else{
                    selectFreshUredjaj = konSatDB.createStatement();

                    String query = "SELECT * FROM gps_fresh where Uredjaj=" + brojUredjaja;
                    rs = selectFreshUredjaj.executeQuery(query);
                    while (rs.next()){
                        Uredjaj ur_fresh = new Uredjaj(
                                rs.getInt("Uredjaj"),
                                rs.getFloat("Wx"),
                                rs.getFloat("Wy"),
                                rs.getString("Gtime"),
                                (short) rs.getInt("Event"),
                                rs.getShort("RunMode"),
                                (long) rs.getFloat("Speed"),
                                rs.getInt("Direct"),
                                rs.getInt("Altitude"),
                                rs.getShort("Satellites"),
                                rs.getShort("GsmSignalLevel"),
                                (int) rs.getFloat("Accuracy"),
                                (int) rs.getFloat("BatteryLevel"),
                                (long) rs.getFloat("Analog1"),
                                (long) rs.getFloat("Analog2"),
                                rs.getFloat("FlsLevel1"),
                                rs.getFloat("FlsLevel2"),
                                rs.getFloat("FuelTemperature1"),
                                rs.getFloat("FuelTemperature2"),
                                (long) rs.getFloat("PowerSupply"),
                                rs.getDouble("Mileage"),
                                (long) rs.getFloat("Odometer"),
                                rs.getString("Geocode"),
                                (short) rs.getShort("fk_ID_vozac"));
                        ur = ur_fresh;
                    }
                    psqlFlag = false;
                }
            }
        }catch(SQLException sqle){
            System.out.println("Greska u Parametri.pozicijaIzFresh\t" + sqle.toString());
            loger.ispisGreska("Greska u Parametri.pozicijaIzFresh\t" + sqle.toString());
        } 
        try {
            if(rs != null) {
                rs.close();
            }
            if(selectFreshUredjaj != null){
                selectFreshUredjaj.close();
            }
        } catch (SQLException ex) {
            System.out.println("Greska prilikom zatvaranja resursa u Parametri.pozicijaIzFresh\t" + ex.toString());
            loger.ispisGreska("Greska prilikom zatvaranja resursa u Parametri.pozicijaIzFresh\t" + ex.toString());
        }
        return ur;
    }
    
    /**
     * Funkicja koja otvara konekciju sa SatDB bazom
     */
    public void konekcijaSatDBBaza() {
        try {
            this.konSatDB = DriverManager.getConnection(url_satdb, user_satdb, password_satdb);
        } catch (SQLException ex) {
            System.out.println("Greska prilikom konekcije sa bazom SatDB(Parametri. konekcijaSatDBBaza())\t" + ex.toString());
            loger.ispisGreska("Greska prilikom konekcije sa bazom SatDB(Parametri. konekcijaSatDBBaza())\t" + ex.toString());
        }
    }
    /**
     * Funkcija koja otvara konekciju ka GIS bazi
     */
    public void konekcijaGISServer(){
        url_gis += ip_gisdb;
        try{
            this.konGIS = DriverManager.getConnection(url_gis, user_gis, password_gis);
        }catch (SQLException ex){
            System.out.println("Greska prilikom konekcije sa GIS(Parametri.konekcijaGIS())\t" + ex.toString());
            loger.ispisGreska("Greska prilikom konekcije sa GIS(Parametri.konekcijaGIS())\t" + ex.toString());
        }
    }
    
    

    
    
    //<editor-fold defaultstate="collapsed" desc="Formatiranje datuma">
    public String formatDatum(Date datum){
        return DATUM.format(datum);
    }
    
    public String formatVrijeme(Date datum){
        return VRIJEME.format(datum);
    }
    
    public String formatDatumIVrijeme(Date datum){
        return DATUMVRIJEME.format(datum);
    }
//</editor-fold>
    
    
    //<editor-fold defaultstate="collapsed" desc="Getter i setter funkcije">
    public String getAppserver() {
        return appserver;
    }
    //</editor-fold>
    
    
//<editor-fold defaultstate="collapsed" desc="SQL Stringovi">
    /*String upit = "SELECT COUNT(*) FROM gps WHERE Uredjaj = " + jtfBrojUredjaja.getText() + " AND Gtime > '" + jtfManjeOdGtime.getText() + "' AND Gtime < '" + jtfVeceOdGtime.getText() + "'";*/
//</editor-fold>
    

}
